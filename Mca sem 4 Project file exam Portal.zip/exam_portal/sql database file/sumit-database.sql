-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 25, 2024 at 05:48 AM
-- Server version: 5.7.42-0ubuntu0.18.04.1-log
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sumit-database`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer_sheet`
--

CREATE TABLE `answer_sheet` (
  `id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `question` text NOT NULL,
  `option1` varchar(255) NOT NULL,
  `option2` varchar(255) NOT NULL,
  `option3` varchar(255) NOT NULL,
  `option4` varchar(255) NOT NULL,
  `answer` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `answer_sheet`
--

INSERT INTO `answer_sheet` (`id`, `test_id`, `question`, `option1`, `option2`, `option3`, `option4`, `answer`, `created_at`) VALUES
(375, 21, 'Whats your state name?', 'up', 'mp', 'J&K', 'haryana', 'Rajasthan', '2024-10-26 17:29:50'),
(376, 22, 'What is the capital of France?', 'Paris', 'London', 'Berlin', 'Madrid', 'Paris', '2024-10-27 11:56:44'),
(377, 22, 'Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Mars', '2024-10-27 11:56:44'),
(378, 22, 'Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Mars', '2024-10-27 11:57:29'),
(379, 24, 'What is your name', 'p1', 'p2', 'p3', 'p4', 'p1', '2024-11-05 05:14:26'),
(380, 24, 'Your age?', '12', '23', '23', '23', '12', '2024-11-05 05:14:26'),
(381, 25, 'What is your name', 'p1', 'p2', 'p3', 'p4', 'p1', '2024-11-05 06:29:15'),
(382, 25, 'Your age?', '12', '23', '23', '23', '12', '2024-11-05 06:29:15'),
(383, 26, 'What is the capital of France?', 'Berlin', 'Madrid', 'Paris', 'Rome', 'Paris', '2024-11-14 07:02:51'),
(384, 26, 'Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Venus', 'Jupiter', 'Mars', '2024-11-14 07:02:51'),
(385, 26, 'Who wrote \"Romeo and Juliet\"?', 'William Blake', 'J.K. Rowling', 'William Shakespeare', 'Charles Dickens', 'William Shakespeare', '2024-11-14 07:02:51'),
(386, 26, 'What is the largest mammal?', 'Elephant', 'Blue Whale', 'Shark', 'Giraffe', 'Blue Whale', '2024-11-14 07:02:51'),
(387, 26, 'What is the chemical symbol for water?', 'H2O', 'CO2', 'O2', 'NaCl', 'H2O', '2024-11-14 07:02:51'),
(388, 26, 'Who is known as the \"Father of Computers\"?', 'Bill Gates', 'Charles Babbage', 'Steve Jobs', 'Alan Turing', 'Charles Babbage', '2024-11-14 07:02:51'),
(389, 26, 'What is the fastest land animal?', 'Cheetah', 'Lion', 'Eagle', 'Gazelle', 'Cheetah', '2024-11-14 07:02:51'),
(390, 26, 'Which element has the atomic number 1?', 'Helium', 'Oxygen', 'Hydrogen', 'Carbon', 'Hydrogen', '2024-11-14 07:02:51'),
(391, 26, 'In which year did World War II end?', '1940', '1945', '1950', '1960', '1945', '2024-11-14 07:02:51'),
(392, 26, 'What is the currency of Japan?', 'Yuan', 'Yen', 'Dollar', 'Won', 'Yen', '2024-11-14 07:02:51'),
(393, 29, 'What is the capital of France?', 'London', 'Paris', 'Berlin', 'Madrid', 'Paris', '2024-11-15 05:35:12'),
(394, 29, 'Who wrote \"Romeo and Juliet\"?', 'Charles Dickens', 'William Shakespeare', 'Mark Twain', 'Jane Austen', 'William Shakespeare', '2024-11-15 05:35:12'),
(395, 29, 'What is the largest planet in our solar system?', 'Earth', 'Venus', 'Jupiter', 'Saturn', 'Jupiter', '2024-11-15 05:35:12'),
(396, 29, 'Who painted the \"Mona Lisa\"?', 'Vincent van Gogh', 'Michelangelo', 'Pablo Picasso', 'Leonardo da Vinci', 'Leonardo da Vinci', '2024-11-15 05:35:12'),
(397, 29, 'Who discovered gravity when an apple fell on his head?', 'Isaac Newton', 'Albert Einstein', 'Galileo Galilei', 'Thomas Edison', 'Isaac Newton', '2024-11-15 05:35:12'),
(398, 29, 'What is the capital of Japan?', 'Seoul', 'Beijing', 'Tokyo', 'Bangkok', 'Tokyo', '2024-11-15 05:35:12'),
(399, 29, 'Who developed the theory of relativity?', 'Nikola Tesla', 'Albert Einstein', 'Isaac Newton', 'Marie Curie', 'Albert Einstein', '2024-11-15 05:35:12'),
(400, 29, 'What is the smallest prime number?', '1', '2', '3', '5', '2', '2024-11-15 05:35:12'),
(401, 29, 'Which organ pumps blood through the body?', 'Lungs', 'Liver', 'Heart', 'Kidney', 'Heart', '2024-11-15 05:35:12'),
(402, 29, 'What is the chemical symbol for water?', 'CO2', 'H2O', 'O2', 'NaCl', 'H2O', '2024-11-15 05:35:12'),
(403, 29, 'Which country gifted the Statue of Liberty to the USA?', 'United Kingdom', 'France', 'Canada', 'Spain', 'France', '2024-11-15 05:35:12'),
(404, 29, 'Who is the author of \"Harry Potter\" series?', 'J.K. Rowling', 'J.R.R. Tolkien', 'Stephen King', 'George Orwell', 'J.K. Rowling', '2024-11-15 05:35:12'),
(405, 29, 'What is the largest mammal in the world?', 'Elephant', 'Blue Whale', 'Great White Shark', 'Hippopotamus', 'Blue Whale', '2024-11-15 05:35:12'),
(406, 29, 'In which continent is the Sahara Desert located?', 'Asia', 'Australia', 'Africa', 'South America', 'Africa', '2024-11-15 05:35:12'),
(407, 29, 'What gas do plants absorb from the atmosphere?', 'Oxygen', 'Nitrogen', 'Carbon Dioxide', 'Helium', 'Carbon Dioxide', '2024-11-15 05:35:12'),
(408, 29, 'Who was the first man to walk on the moon?', 'Buzz Aldrin', 'Michael Collins', 'Neil Armstrong', 'Yuri Gagarin', 'Neil Armstrong', '2024-11-15 05:35:12'),
(409, 29, 'How many continents are there on Earth?', '5', '6', '7', '8', '7', '2024-11-15 05:35:12'),
(410, 29, 'What is the hardest natural substance on Earth?', 'Gold', 'Iron', 'Diamond', 'Silver', 'Diamond', '2024-11-15 05:35:12'),
(411, 29, 'Which planet is known as the \"Red Planet\"?', 'Mars', 'Venus', 'Jupiter', 'Mercury', 'Mars', '2024-11-15 05:35:12'),
(412, 27, 'what is your name?', 'p1', 'p2', 'p3', 'p4', 'p1', '2024-11-15 12:24:00');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `mobile`, `subject`, `msg`, `created_at`) VALUES
(10, 'Vikas vaishnav', 'sony2607@gmail.com', '8398013122', 'sdfsd', 'Gf', '2024-11-14 23:12:13'),
(11, 'JASWANT SINGH CHOUHAN', 'rajputjaswant335@gmail.com', '0637632214', 'drtfgdrg', 'fg', '2024-11-15 03:51:43');

-- --------------------------------------------------------

--
-- Table structure for table `course_details`
--

CREATE TABLE `course_details` (
  `id` int(11) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `admin_id` int(10) NOT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course_details`
--

INSERT INTO `course_details` (`id`, `course_name`, `admin_id`, `status`, `created_at`) VALUES
(242, 'SSC MTS', 117, 'active', '2024-10-18 05:29:25'),
(243, 'RAS', 117, 'active', '2024-10-23 17:13:40'),
(244, 'IAS', 117, 'active', '2024-11-05 05:10:16'),
(245, 'UTK Course', 117, 'active', '2024-11-05 06:27:53');

-- --------------------------------------------------------

--
-- Table structure for table `exam_assign_details`
--

CREATE TABLE `exam_assign_details` (
  `id` int(255) NOT NULL,
  `admin_id` int(255) NOT NULL,
  `std_id` int(255) NOT NULL,
  `test_id` int(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_assign_details`
--

INSERT INTO `exam_assign_details` (`id`, `admin_id`, `std_id`, `test_id`, `status`, `created_at`) VALUES
(12, 117, 291, 29, 'active', '2024-11-15 17:30:41'),
(13, 117, 293, 27, 'active', '2024-11-15 17:54:37'),
(14, 117, 297, 29, 'active', '2024-11-18 15:14:19');

-- --------------------------------------------------------

--
-- Table structure for table `org_details`
--

CREATE TABLE `org_details` (
  `id` int(11) NOT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `mobile` varchar(255) NOT NULL,
  `state` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `otp` int(6) NOT NULL,
  `otp_generated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `org_details`
--

INSERT INTO `org_details` (`id`, `org_name`, `owner_name`, `role`, `mobile`, `state`, `district`, `pincode`, `location`, `otp`, `otp_generated_at`) VALUES
(117, 'sumit tech company', 'Sumit saini', 'admin', '9887724031', 'Rajasthan', 'Sikar', 332718, 'Village Shyalodra', 2479, '2024-11-18 15:13:07'),
(118, 'Khowal tech', 'Pankaj khowal', 'user', '8398013122', 'Rajasthan', 'Sikar', 332718, 'Jodhpur', 1250, '2024-11-03 13:21:32'),
(119, NULL, NULL, 'user', '1234567890', NULL, NULL, NULL, NULL, 3760, '2024-11-18 08:53:03'),
(120, 'js pvt. ltd.', 'jaswant singh Chouhan', 'user', '6376322145', 'Rajasthan', 'Jodhpur', 342001, 'miraaz cinema jodhpur', 6589, '2024-11-15 03:55:27');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `std_id` int(11) NOT NULL,
  `total_question` int(11) NOT NULL,
  `correct_answer` int(11) NOT NULL,
  `wrong_answer` int(11) NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `status` varchar(50) NOT NULL,
  `exam_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`id`, `test_id`, `std_id`, `total_question`, `correct_answer`, `wrong_answer`, `score`, `status`, `exam_date`, `created_at`) VALUES
(36, 26, 294, 10, 0, 10, '0.00', 'Failed', '2024-11-14 09:23:26', '2024-11-14 08:58:45'),
(37, 27, 291, 1, 0, 1, '0.00', 'Failed', '2024-11-15 12:24:12', '2024-11-15 12:24:12'),
(38, 29, 291, 19, 0, 19, '0.00', 'Failed', '2024-11-24 15:27:50', '2024-11-18 09:44:34'),
(39, 29, 291, 19, 0, 19, '0.00', 'Failed', '2024-11-24 15:27:50', '2024-11-18 09:44:34'),
(40, 29, 297, 19, 5, 14, '26.32', 'Failed', '2024-11-18 15:16:06', '2024-11-18 15:16:06');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `id` int(11) NOT NULL,
  `std_name` varchar(255) NOT NULL,
  `std_mobile` varchar(255) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `batch_id` int(11) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_details`
--

INSERT INTO `student_details` (`id`, `std_name`, `std_mobile`, `admin_id`, `batch_id`, `password`, `status`, `created_at`) VALUES
(291, 'sumit khowal', '9887724031', 117, 242, '9887724031', 'active', '2024-11-15 05:44:20'),
(292, 'Imran', '9887724032', 117, 243, '9887724031', 'active', '2024-11-15 09:28:03'),
(293, 'pradeep', '1234567890', 117, 244, '1234567890', 'active', '2024-11-15 09:27:58'),
(294, 'testing student', '7850999717', 117, 245, '7850999717', 'active', '2024-11-15 05:44:26'),
(295, 'suman', '7894561230', 117, 245, '7894561230', 'active', '2024-11-15 09:27:43'),
(296, 'pooja', '7878787878', 117, 243, '7878787878', 'active', '2024-11-15 09:27:49'),
(297, 'Vikash', '7568230177', 117, 244, '7568230177', 'active', '2024-11-18 15:13:44');

-- --------------------------------------------------------

--
-- Table structure for table `submit_exam`
--

CREATE TABLE `submit_exam` (
  `id` int(11) NOT NULL,
  `std_id` int(255) NOT NULL,
  `test_id` int(255) NOT NULL,
  `answers_data` json DEFAULT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submit_exam`
--

INSERT INTO `submit_exam` (`id`, `std_id`, `test_id`, `answers_data`, `submitted_at`) VALUES
(89, 294, 26, '[{\"question_id\": 383, \"correct_answer\": \"Paris\", \"selected_answer\": null}, {\"question_id\": 384, \"correct_answer\": \"Mars\", \"selected_answer\": null}, {\"question_id\": 385, \"correct_answer\": \"William Shakespeare\", \"selected_answer\": null}, {\"question_id\": 386, \"correct_answer\": \"Blue Whale\", \"selected_answer\": null}, {\"question_id\": 387, \"correct_answer\": \"H2O\", \"selected_answer\": null}, {\"question_id\": 388, \"correct_answer\": \"Charles Babbage\", \"selected_answer\": null}, {\"question_id\": 389, \"correct_answer\": \"Cheetah\", \"selected_answer\": null}, {\"question_id\": 390, \"correct_answer\": \"Hydrogen\", \"selected_answer\": null}, {\"question_id\": 391, \"correct_answer\": \"1945\", \"selected_answer\": null}, {\"question_id\": 392, \"correct_answer\": \"Yen\", \"selected_answer\": null}]', '2024-11-14 09:23:26'),
(90, 291, 22, '[{\"question_id\": 376, \"correct_answer\": \"Paris\", \"selected_answer\": \"Paris\"}, {\"question_id\": 377, \"correct_answer\": \"Mars\", \"selected_answer\": \"Mars\"}, {\"question_id\": 378, \"correct_answer\": \"Mars\", \"selected_answer\": \"Jupiter\"}]', '2024-11-14 08:53:58'),
(91, 291, 27, '[{\"question_id\": 412, \"correct_answer\": \"p1\", \"selected_answer\": null}]', '2024-11-15 12:24:12'),
(92, 291, 29, '[{\"question_id\": 393, \"correct_answer\": \"Paris\", \"selected_answer\": null}, {\"question_id\": 394, \"correct_answer\": \"William Shakespeare\", \"selected_answer\": null}, {\"question_id\": 395, \"correct_answer\": \"Jupiter\", \"selected_answer\": null}, {\"question_id\": 396, \"correct_answer\": \"Leonardo da Vinci\", \"selected_answer\": null}, {\"question_id\": 397, \"correct_answer\": \"Isaac Newton\", \"selected_answer\": null}, {\"question_id\": 398, \"correct_answer\": \"Tokyo\", \"selected_answer\": null}, {\"question_id\": 399, \"correct_answer\": \"Albert Einstein\", \"selected_answer\": null}, {\"question_id\": 400, \"correct_answer\": \"2\", \"selected_answer\": null}, {\"question_id\": 401, \"correct_answer\": \"Heart\", \"selected_answer\": null}, {\"question_id\": 402, \"correct_answer\": \"H2O\", \"selected_answer\": null}, {\"question_id\": 403, \"correct_answer\": \"France\", \"selected_answer\": null}, {\"question_id\": 404, \"correct_answer\": \"J.K. Rowling\", \"selected_answer\": null}, {\"question_id\": 405, \"correct_answer\": \"Blue Whale\", \"selected_answer\": null}, {\"question_id\": 406, \"correct_answer\": \"Africa\", \"selected_answer\": null}, {\"question_id\": 407, \"correct_answer\": \"Carbon Dioxide\", \"selected_answer\": null}, {\"question_id\": 408, \"correct_answer\": \"Neil Armstrong\", \"selected_answer\": null}, {\"question_id\": 409, \"correct_answer\": \"7\", \"selected_answer\": null}, {\"question_id\": 410, \"correct_answer\": \"Diamond\", \"selected_answer\": null}, {\"question_id\": 411, \"correct_answer\": \"Mars\", \"selected_answer\": null}]', '2024-11-24 15:27:49'),
(93, 297, 29, '[{\"question_id\": 393, \"correct_answer\": \"Paris\", \"selected_answer\": \"Paris\"}, {\"question_id\": 394, \"correct_answer\": \"William Shakespeare\", \"selected_answer\": \"William Shakespeare\"}, {\"question_id\": 395, \"correct_answer\": \"Jupiter\", \"selected_answer\": \"Venus\"}, {\"question_id\": 396, \"correct_answer\": \"Leonardo da Vinci\", \"selected_answer\": \"Michelangelo\"}, {\"question_id\": 397, \"correct_answer\": \"Isaac Newton\", \"selected_answer\": \"Galileo Galilei\"}, {\"question_id\": 398, \"correct_answer\": \"Tokyo\", \"selected_answer\": \"Tokyo\"}, {\"question_id\": 399, \"correct_answer\": \"Albert Einstein\", \"selected_answer\": \"Isaac Newton\"}, {\"question_id\": 400, \"correct_answer\": \"2\", \"selected_answer\": \"2\"}, {\"question_id\": 401, \"correct_answer\": \"Heart\", \"selected_answer\": \"Liver\"}, {\"question_id\": 402, \"correct_answer\": \"H2O\", \"selected_answer\": \"CO2\"}, {\"question_id\": 403, \"correct_answer\": \"France\", \"selected_answer\": \"France\"}, {\"question_id\": 404, \"correct_answer\": \"J.K. Rowling\", \"selected_answer\": \"Stephen King\"}, {\"question_id\": 405, \"correct_answer\": \"Blue Whale\", \"selected_answer\": \"Great White Shark\"}, {\"question_id\": 406, \"correct_answer\": \"Africa\", \"selected_answer\": \"Australia\"}, {\"question_id\": 407, \"correct_answer\": \"Carbon Dioxide\", \"selected_answer\": \"Nitrogen\"}, {\"question_id\": 408, \"correct_answer\": \"Neil Armstrong\", \"selected_answer\": \"Michael Collins\"}, {\"question_id\": 409, \"correct_answer\": \"7\", \"selected_answer\": \"6\"}, {\"question_id\": 410, \"correct_answer\": \"Diamond\", \"selected_answer\": \"Iron\"}, {\"question_id\": 411, \"correct_answer\": \"Mars\", \"selected_answer\": \"Venus\"}]', '2024-11-18 15:16:06'),
(94, 297, 29, '[{\"question_id\": 393, \"correct_answer\": \"Paris\", \"selected_answer\": \"Paris\"}, {\"question_id\": 394, \"correct_answer\": \"William Shakespeare\", \"selected_answer\": \"William Shakespeare\"}, {\"question_id\": 395, \"correct_answer\": \"Jupiter\", \"selected_answer\": \"Venus\"}, {\"question_id\": 396, \"correct_answer\": \"Leonardo da Vinci\", \"selected_answer\": \"Michelangelo\"}, {\"question_id\": 397, \"correct_answer\": \"Isaac Newton\", \"selected_answer\": \"Galileo Galilei\"}, {\"question_id\": 398, \"correct_answer\": \"Tokyo\", \"selected_answer\": \"Tokyo\"}, {\"question_id\": 399, \"correct_answer\": \"Albert Einstein\", \"selected_answer\": \"Isaac Newton\"}, {\"question_id\": 400, \"correct_answer\": \"2\", \"selected_answer\": \"2\"}, {\"question_id\": 401, \"correct_answer\": \"Heart\", \"selected_answer\": \"Liver\"}, {\"question_id\": 402, \"correct_answer\": \"H2O\", \"selected_answer\": \"CO2\"}, {\"question_id\": 403, \"correct_answer\": \"France\", \"selected_answer\": \"France\"}, {\"question_id\": 404, \"correct_answer\": \"J.K. Rowling\", \"selected_answer\": \"Stephen King\"}, {\"question_id\": 405, \"correct_answer\": \"Blue Whale\", \"selected_answer\": \"Great White Shark\"}, {\"question_id\": 406, \"correct_answer\": \"Africa\", \"selected_answer\": \"Australia\"}, {\"question_id\": 407, \"correct_answer\": \"Carbon Dioxide\", \"selected_answer\": \"Nitrogen\"}, {\"question_id\": 408, \"correct_answer\": \"Neil Armstrong\", \"selected_answer\": \"Michael Collins\"}, {\"question_id\": 409, \"correct_answer\": \"7\", \"selected_answer\": \"6\"}, {\"question_id\": 410, \"correct_answer\": \"Diamond\", \"selected_answer\": \"Iron\"}, {\"question_id\": 411, \"correct_answer\": \"Mars\", \"selected_answer\": \"Venus\"}]', '2024-11-18 15:16:06'),
(95, 297, 29, '[{\"question_id\": 393, \"correct_answer\": \"Paris\", \"selected_answer\": \"Paris\"}, {\"question_id\": 394, \"correct_answer\": \"William Shakespeare\", \"selected_answer\": \"William Shakespeare\"}, {\"question_id\": 395, \"correct_answer\": \"Jupiter\", \"selected_answer\": \"Venus\"}, {\"question_id\": 396, \"correct_answer\": \"Leonardo da Vinci\", \"selected_answer\": \"Michelangelo\"}, {\"question_id\": 397, \"correct_answer\": \"Isaac Newton\", \"selected_answer\": \"Galileo Galilei\"}, {\"question_id\": 398, \"correct_answer\": \"Tokyo\", \"selected_answer\": \"Tokyo\"}, {\"question_id\": 399, \"correct_answer\": \"Albert Einstein\", \"selected_answer\": \"Isaac Newton\"}, {\"question_id\": 400, \"correct_answer\": \"2\", \"selected_answer\": \"2\"}, {\"question_id\": 401, \"correct_answer\": \"Heart\", \"selected_answer\": \"Liver\"}, {\"question_id\": 402, \"correct_answer\": \"H2O\", \"selected_answer\": \"CO2\"}, {\"question_id\": 403, \"correct_answer\": \"France\", \"selected_answer\": \"France\"}, {\"question_id\": 404, \"correct_answer\": \"J.K. Rowling\", \"selected_answer\": \"Stephen King\"}, {\"question_id\": 405, \"correct_answer\": \"Blue Whale\", \"selected_answer\": \"Great White Shark\"}, {\"question_id\": 406, \"correct_answer\": \"Africa\", \"selected_answer\": \"Australia\"}, {\"question_id\": 407, \"correct_answer\": \"Carbon Dioxide\", \"selected_answer\": \"Nitrogen\"}, {\"question_id\": 408, \"correct_answer\": \"Neil Armstrong\", \"selected_answer\": \"Michael Collins\"}, {\"question_id\": 409, \"correct_answer\": \"7\", \"selected_answer\": \"6\"}, {\"question_id\": 410, \"correct_answer\": \"Diamond\", \"selected_answer\": \"Iron\"}, {\"question_id\": 411, \"correct_answer\": \"Mars\", \"selected_answer\": \"Venus\"}]', '2024-11-18 15:16:06');

-- --------------------------------------------------------

--
-- Table structure for table `test_details`
--

CREATE TABLE `test_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `batch_id` int(10) UNSIGNED NOT NULL,
  `admin_id` int(11) NOT NULL,
  `test_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `strt_date` date NOT NULL,
  `t_time` int(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `test_details`
--

INSERT INTO `test_details` (`id`, `batch_id`, `admin_id`, `test_name`, `strt_date`, `t_time`, `created_at`, `status`) VALUES
(27, 242, 117, 'ssc mts test', '2024-11-21', 40, '2024-11-15 05:15:57', 'active'),
(28, 243, 117, 'RAS', '2024-11-17', 60, '2024-11-15 05:16:37', 'active'),
(29, 244, 117, 'ias mock exam (test)', '2024-11-04', 1, '2024-11-15 05:17:53', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answer_sheet`
--
ALTER TABLE `answer_sheet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course_details`
--
ALTER TABLE `course_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exam_assign_details`
--
ALTER TABLE `exam_assign_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `org_details`
--
ALTER TABLE `org_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submit_exam`
--
ALTER TABLE `submit_exam`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_details`
--
ALTER TABLE `test_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answer_sheet`
--
ALTER TABLE `answer_sheet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=413;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `course_details`
--
ALTER TABLE `course_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=246;

--
-- AUTO_INCREMENT for table `exam_assign_details`
--
ALTER TABLE `exam_assign_details`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `org_details`
--
ALTER TABLE `org_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `results`
--
ALTER TABLE `results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `submit_exam`
--
ALTER TABLE `submit_exam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `test_details`
--
ALTER TABLE `test_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
