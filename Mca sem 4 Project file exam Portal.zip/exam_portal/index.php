<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UTKARSH CLASSES</title>
    <link rel="icon" type="image/x-icon" href="./assets/images/utkarsh_fevicon.png">
     <link rel="stylesheet" href="./assets/bootstrap/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://kit.fontawesome.com/c92e53a223.js"></script>
    <link rel="stylesheet" href="./assets/css/style.css">
    <style>
        #snackbar {
            visibility: hidden;
            min-width: 250px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            left: 50%;
            bottom: 30px;
            transform: translateX(-50%);
            font-size: 17px;
        }

        #snackbar.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {
                bottom: 0;
                opacity: 0;
            }

            to {
                bottom: 30px;
                opacity: 1;
            }
        }

        @keyframes fadein {
            from {
                bottom: 0;
                opacity: 0;
            }

            to {
                bottom: 30px;
                opacity: 1;
            }
        }

        @-webkit-keyframes fadeout {
            from {
                bottom: 30px;
                opacity: 1;
            }

            to {
                bottom: 0;
                opacity: 0;
            }
        }

        @keyframes fadeout {
            from {
                bottom: 30px;
                opacity: 1;
            }

            to {
                bottom: 0;
                opacity: 0;
            }
        }
    </style>
    <script>
        function showSnackbar(message) {
            var snackbar = document.getElementById("snackbar");
            snackbar.textContent = message;
            snackbar.className = "show";

            setTimeout(function () {
                snackbar.className = snackbar.className.replace("show", "");
            }, 3000);
        }
    </script>
</head>
<style>
    .body-content {
        background-image: url('./assets/images/body-bg.png');
    }
</style>

<body>
    <div id="snackbar">This is a default message</div>
    <div class="container-fluid d-flex justify-content-between bg-dark p-1" style="position:sticky;top:0;z-index:999">
        <a href="index.php" class="text-light text-decoration-none"><i class="fa-solid fa-building me-2"></i> SK TECH COMPANY</a>
        <h4 class="text-light">Digital Portal</h4>
        <a href="tel:+919887724031" class="text-light text-decoration-none"><i class="fa-solid fa-mobile me-2"></i> 9887724031</a>
    </div>
    <div class="main">

        <?php
        session_start();
        include "connection.php";
        if (!isset($_SESSION['step'])) {
            $_SESSION['step'] = 'sendOtp';
        }
        $error_msg = '';

        if (isset($_POST['sendOtp'])) {
            $mobile = $_POST['mobile'];
            if (!is_numeric($mobile) || strlen($mobile) != 10) {
                $error_msg = 'Please enter a valid 10-digit mobile number.';
            } else {
                $otp = rand(1000, 9999);
                $_SESSION['otp'] = $otp;
                $_SESSION['mobile'] = $mobile;
                $stmt = $conn->prepare("SELECT org_name, owner_name FROM org_details WHERE mobile = ?");
                $stmt->bind_param("s", $mobile);
                $stmt->execute();
                $result_check_mobile = $stmt->get_result();

                if ($result_check_mobile->num_rows > 0) {
                    $row = $result_check_mobile->fetch_assoc();
                    if (empty($row['org_name']) || empty($row['owner_name'])) {
                        $update_stmt = $conn->prepare("UPDATE org_details SET otp = ?, otp_generated_at = NOW() WHERE mobile = ?");
                        $update_stmt->bind_param("is", $otp, $mobile);
                        if ($update_stmt->execute()) {
                            $msg = "Use " . $otp . " as one time password(OTP). From Utkarsh Classes";
                            $message_content = urlencode($msg);
                            $apiUrl = "http://www.smscountry.com/SMSCwebservice_Bulk.aspx?User=nirmal.gahlot&passwd=k2X0d8eQV4UK&mobilenumber={$mobile}&message={$message_content}&sid=UTKRSH&mtype=N&DR=Y";

                            $ch = curl_init($apiUrl);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                            $response = curl_exec($ch);
                            curl_close($ch);
                            echo "<script>
                        Swal.fire({
                          icon: 'success',
                          title: 'OTP sent successfully',
                          showConfirmButton: false,
                          timer: 1500
                        }).then(() => {
               
                document.getElementById('registration-form').scrollIntoView({ behavior: 'smooth' });
               
                var otpInput = document.getElementById('otp-input');
                if (otpInput) {
                    otpInput.focus();
                }
            });
                        </script>";
                            $_SESSION['step'] = 'verifyOtp';
                        } else {
                            echo "<script>
                        Swal.fire({
                          icon: 'error',
                          title: 'Error updating OTP',
                          text: 'Please try again later.',
                          showConfirmButton: true
                        });
                        </script>";
                        }
                        $update_stmt->close();
                    } else {
                        if (!isset($_SESSION['alert_shown'])) {
                            session_unset();
                            session_destroy();
                            header("Location: https://form.utkarsh.com/sumit/payment/exam_portal/admin");
                            exit();
                        }
                        // $_SESSION['step'] = 'sendOtp';
                    }
                } else {
                    $insert_stmt = $conn->prepare("INSERT INTO org_details (mobile, otp, otp_generated_at) VALUES (?, ?, NOW())");
                    $insert_stmt->bind_param("si", $mobile, $otp);
                    if ($insert_stmt->execute()) {
                        $msg = "Use " . $otp . " as one time password(OTP). From Utkarsh Classes";
                        $message_content = urlencode($msg);
                        $apiUrl = "http://www.smscountry.com/SMSCwebservice_Bulk.aspx?User=nirmal.gahlot&passwd=k2X0d8eQV4UK&mobilenumber={$mobile}&message={$message_content}&sid=UTKRSH&mtype=N&DR=Y";

                        $ch = curl_init($apiUrl);
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $response = curl_exec($ch);
                        curl_close($ch);

                        echo "<script>
                    Swal.fire({
                      icon: 'success',
                      title: 'OTP sent successfully',
                      showConfirmButton: false,
                      timer: 1500
                    }).then(() => {
                // Scroll to the OTP section
                document.getElementById('registration-form').scrollIntoView({ behavior: 'smooth' });
                var otpInput = document.getElementById('otp-input');
                if (otpInput) {
                    otpInput.focus();
                }
            });
                    </script>";
                        $_SESSION['step'] = 'verifyOtp';
                    } else {
                        echo "<script>
                    Swal.fire({
                      icon: 'error',
                      title: 'Error registering user',
                      text: 'Please try again later.',
                      showConfirmButton: true
                    });
                    </script>";
                    }
                    $insert_stmt->close();
                }
                $stmt->close();
            }
        }

        if (!isset($_POST['sendOtp'])) {
            unset($_SESSION['alert_shown']);
        }
        if (isset($_POST['resendOtp'])) {
            $newOtp = rand(1000, 9999);
            $_SESSION['otp'] = $newOtp;

            $mobile = $_SESSION['mobile'];
            $stmt = $conn->prepare("UPDATE org_details SET otp = ?, otp_generated_at = NOW() WHERE mobile = ?");
            $stmt->bind_param("ss", $newOtp, $mobile);

            if ($stmt->execute()) {
                echo "<script>showSnackbar('OTP has been resent to your mobile number.');</script>";
                $msg = "Use " . $newOtp . " as one time password(OTP). From Utkarsh Classes";
                $message_content = urlencode($msg);
                $apiUrl = "http://www.smscountry.com/SMSCwebservice_Bulk.aspx?User=nirmal.gahlot&passwd=k2X0d8eQV4UK&mobilenumber={$mobile}&message={$message_content}&sid=UTKRSH&mtype=N&DR=Y";

                $ch = curl_init($apiUrl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
            } else {
                echo "Error updating OTP: " . $conn->error;
            }

            $stmt->close();
        }

        if (isset($_POST['verifyOtp'])) {
            $mobile = $_SESSION['mobile'];
            $otp = $_POST['otp'];

            $sql = "SELECT * FROM org_details WHERE mobile = '$mobile' AND otp = '$otp'";
            if ($result = $conn->query($sql)) {
                if ($result->num_rows > 0) {
                    echo "<script>
            Swal.fire({
              icon: 'success',
              title: 'OTP verified successfully',
              showConfirmButton: false,
              timer: 1500
            }).then(() => {
                document.getElementById('registration-form').scrollIntoView({ behavior: 'smooth' });
                var otpInput = document.getElementById('org_name');
                if (otpInput) {
                    otpInput.focus();
                }
            });
          </script>";
                    $_SESSION['step'] = 'submitForm';

                } else {
                    echo "<script>
            Swal.fire({
              icon: 'error',
              title: 'Invalid OTP',
              text: 'Please try again',
            });
          </script>";
                }
            }
        }

        if (isset($_POST['submit'])) {
            $orgName = trim($_POST['org-name']);
            $ownerName = trim($_POST['owner-name']);
            $state = trim($_POST['state']);
            $district = trim($_POST['district']);
            $location = trim($_POST['location']);
            $pincode = trim($_POST['pincode']);
            $mobile = $_SESSION['mobile'];

            if (empty($state) || empty($district)) {
                echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Please select both State and District.',
        });
        </script>";
            }
            // Validate pincode
            elseif (!is_numeric($pincode) || strlen($pincode) != 6) {
                echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Invalid Pincode',
            text: 'Please enter a valid 6-digit pincode.',
        });
        </script>";
            } else {
                $sql = "UPDATE org_details SET org_name = '$orgName', owner_name = '$ownerName', state='$state',district='$district', location = '$location' , pincode='$pincode'  WHERE mobile = '$mobile'";
                if ($conn->query($sql) === TRUE) {
                    $msg = "Use  as one-time password(OTP). From Utkarsh Classes";
                    $message_content = urlencode($msg);
                    $apiUrl = "http://www.smscountry.com/SMSCwebservice_Bulk.aspx?User=nirmal.gahlot&passwd=k2X0d8eQV4UK&mobilenumber={$mobile}&message={$message_content}&sid=UTKRSH&mtype=N&DR=Y";

                    $ch = curl_init($apiUrl);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $response = curl_exec($ch);
                    curl_close($ch);
                    if (!isset($_SESSION['alert_shown'])) {
                        echo "<script>
    Swal.fire({
        icon: 'success',
        title: 'Thank you! Registration completed successfully | Redirected to The Admin Panel.',
        showConfirmButton: true
    }).then(() => {
        window.location.href = 'https://form.utkarsh.com/sumit/payment/exam_portal/admin/';
    });
</script>";

                        $_SESSION['alert_shown'] = true;
                        session_unset();
                        session_destroy();
                        // session_start();
                        $_SESSION['step'] = 'sendOtp';
                        exit();
                    }
                } else {
                    echo "<script> alert('Error inserting data: " . $conn->error . "'); </script>";
                }

            }
        }
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['back'])) {
            session_unset();
            session_destroy();
            session_start();
            $_SESSION['step'] = 'sendOtp';
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
        if (!isset($_SESSION['step'])) {
            $_SESSION['step'] = 'sendOtp';
        }
        if (isset($_POST['logout'])) {
            $mobile = $_SESSION['mobile'];

            if (!empty($mobile)) {
                $sql_delete_user = "DELETE FROM org_details WHERE mobile = '$mobile'";

                if ($conn->query($sql_delete_user) === TRUE) {
                    echo "<script>
            Swal.fire({
              icon: 'success',
              title: 'You have logout.',
              text:'You data is deleted',
              showConfirmButton: true
            });
            </script>";
                } else {
                    echo "<script>
            Swal.fire({
              icon: 'error',
              title: 'Error deleting details: " . $conn->error . "',
              showConfirmButton: true
            });
            </script>";
                }
            }
            session_destroy();
            // session_start();
            $_SESSION['step'] = 'sendOtp';
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        }
        ?>
        <div class="sidebar d-none d-lg-block">
            <a href="#registration-form" class="apply-now">
                <span class="vertical-text">Apply Now</span>
            </a>
        </div>

        <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="./assets/images/banner-1.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="./assets/images/banner-2.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                    <img src="./assets/images/banner-3.jpg" class="d-block w-100" alt="...">
                </div>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying"
                data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
        <div class="sele-heading text-center">
            <h5 class="">About Us</h5>
        </div>

        <div class="body-content">
            <div class="container  mt-5 shadow bg-light" style="border: 10px solid #fa8158ed;border-radius: 10px;">
                <div class="row g-4">
                    <div class="col-lg-3">
                        <div class="bio_img" style="display: flex;justify-content: center;">
                            <img src="./assets/images/poster.jpeg"  class="img-fluid">
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="bio-content">
                            <ul style="line-height:30px; " class="fw-bold" >
                                <li><i class="fa-solid fa-arrow-right"></i> नए संगठनों को अपनी जानकारी देकर साइन अप करने की अनुमति देता है। पंजीकृत संगठन प्लेटफॉर्म पर लॉग इन करके परीक्षा बनाने और प्रबंधन का कार्य कर सकते हैं।</li>
                                <li><i class="fa-solid fa-arrow-right"></i> एक केंद्रीय इंटरफ़ेस जहां संगठन अपने पाठ्यक्रमों, छात्रों और परीक्षाओं का प्रबंधन एक ही स्थान से कर सकते हैं।</li>
                                <li><i class="fa-solid fa-arrow-right"></i> संगठनों को पाठ्यक्रम बनाने, संपादित करने और हटाने की सुविधा देता है, जो परीक्षाओं को व्यवस्थित करने के लिए श्रेणियों के रूप में कार्य करते हैं।</li>
                                <li><i class="fa-solid fa-arrow-right"></i> संगठनों को छात्रों को सिस्टम में जोड़ने और उन्हें पाठ्यक्रमों में नामांकित करने की सुविधा देता है, जिसमें संपर्क जानकारी जैसी जानकारी को संग्रहीत किया जाता है।</li>
                                <li><i class="fa-solid fa-arrow-right"></i> पंजीकृत छात्र लॉग इन करके अपनी आवंटित परीक्षाएँ देख सकते हैं, उन्हें शुरू कर सकते हैं, और निर्धारित समय सीमा में प्रश्नों का उत्तर दे सकते हैं।</li>
                                <li><i class="fa-solid fa-arrow-right"></i> सबमिट करने पर, छात्रों के उत्तर को डेटाबेस में संग्रहीत सही उत्तरों से तुलना कर स्वचालित रूप से ग्रेड किया जाता है।</li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="">
                        <div class="" id="registration-form">
                            <hr class="m-0">
                            <div class="sele-heading text-center">
                                <h5 class="">Registration Form</h5>
                            </div>
                            <?php if ($_SESSION['step'] == 'sendOtp'): ?>
                                <div class="sendOtp" id="sendOtp">
                                    <form action="" method="POST">
                                        <div class="py-5 p-3">
                                            <div class="row">
                                                <div class="col-12 col-lg-6 mb-3">
                                                    <div class="info-section">
                                                        <h3 class="fw-bold text-danger">महत्वपूर्ण जानकारी: </h3>
                                                        <ul >
                                                            <li>यहां स्वयं को रजिस्टर करें और अपनी प्रोफ़ाइल बनाएं।</li>
                                                            <li>परीक्षाएं तैयार करें और उनका प्रबंधन करें।</li>
                                                            <li>छात्रों को जोड़ें और उनके टेस्ट को ट्रैक करें।</li>
                                                            <li>अपने संस्थान की जानकारी को अपडेट और सुरक्षित रखें।</li>
                                                        </ul>
                                                    </div>

                                                </div>
                                                <div class=" border-start col-12 col-lg-6 mb-3">
                                                    <label for="mobile" class="form-label">जिस मोबाइल नंबर से आप आवेदन करना चाहते है, वह यहाँ दर्ज करें।<span class="text-danger">*</span></label>
                                                    <input type="tel" pattern="[0-9]{10}" class="form-control" name="mobile" placeholder="Enter Mobile Number" required>
                                                    <p id="error" class="text-danger"><?php echo $error_msg; ?></p>
                                                    <div class="text-end mb-3">
                                                        <input type="submit" name="sendOtp" value="Send OTP" class="btn btn-dark">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>
                            <!-- otp verification form -->
                            <?php if ($_SESSION['step'] == 'verifyOtp'): ?>
                                <div class="verifyOtp" id="verifyOtp">
                                    <div class="text-end">
                                        <form action="" method="POST">
                                            <button type="submit" name="back" class="btn btn-danger">Back</button>
                                        </form>
                                    </div>

                                    <div class="py-5 p-3">
                                        <div class="row">
                                            <div class="col-12 col-lg-6 mb-3">
                                                <div class="info-section">
                                                    <h3 class="text-danger fw-bold">महत्वपूर्ण जानकारी: </h3>
                                                    <ul>
                                                        <li>यहां स्वयं को रजिस्टर करें और अपनी प्रोफ़ाइल बनाएं।</li>
                                                        <li>परीक्षाएं तैयार करें और उनका प्रबंधन करें।</li>
                                                        <li>छात्रों को जोड़ें और उनके टेस्ट को ट्रैक करें।</li>
                                                        <li>अपने संस्थान की जानकारी को अपडेट और सुरक्षित रखें।</li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="border-start col-12 col-lg-6 mb-3">
                                                <form action="" method="POST">
                                                    <label for="otp" class="form-label">मोबाइल नंबर पर भेजे गए OTP यहाँ दर्ज करें।<span class="text-danger">*</span></label>
                                                    <input type="number" class="form-control" id="otp-input" name="otp" placeholder="Enter OTP" required>
                                                    <div class="text-end mt-2 mb-3">
                                                        <input type="submit" name="verifyOtp" class="btn btn-dark" value="Verify OTP">
                                                    </div>
                                                </form>
                                                <div class="text-center">
                                                    <form action="" method="POST">
                                                        <button type="submit" id="resendOtpBtn" class="border-0" style="display:none;background:none;" name="resendOtp">Resend OTP</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            <?php endif; ?>

                            <!-- appointment form -->
                            <?php if ($_SESSION['step'] == 'submitForm'): ?>
                                <div class="submitForm" id="submitForm">
                                    <div class="m-2 d-flex justify-content-end">
                                        <form action="" method="POST">
                                            <input type="submit" name="logout" value="Logout" class="btn btn-danger">
                                        </form>
                                    </div>
                                    <form action="" method="POST" class="">
                                        <div class="row">
                                            <div class="col-12 col-lg-6 mb-3">
                                                <label for="org-name" class="form-label">Organization name</label>
                                                <input type="text" class="form-control" id="org_name" name="org-name" placeholder="Enter Organization Name" required>
                                            </div>
                                            <div class="col-12 col-lg-6 mb-3">
                                                <label for="owner-name" class="form-label">Owner Name</label>
                                                <input type="text" class="form-control" name="owner-name" placeholder="Enter Owner Name" required>
                                            </div>
                                            <div class="col-12 col-lg-4 mb-3">
                                                <label for="state" class="form-label">State</label>
                                                <select class="form-select" name="state" id="state" required>
                                                    <option value="">Select State</option>
                                                </select>
                                            </div>
                                            <div class="col-12 col-lg-4 mb-3">
                                                <label for="district" class="form-label">District</label>
                                                <select class="form-select" name="district" id="district" required>
                                                    <option value="">Select District</option>
                                                </select>
                                            </div>
                                            <div class="col-12 col-lg-4 mb-3">
                                                <label for="pincode" class="form-label">Pincode</label>
                                                <input type="tel" pattern="[0-9]{6}" class="form-control" name="pincode" placeholder="Enter Pincode" required>
                                            </div>
                                            <div class="col-12 col-lg-12 mb-3">
                                                <label for="location" class="form-label">Address</label>
                                                <textarea name="location" placeholder="Enter Address" class="form-control" required></textarea>
                                            </div>
                                            <div class=" mb-3 text-center text-lg-end">
                                                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
            <div class="container mb-5">
                <div class="sele-heading text-center">
                    <h5 class="text-center">Features</h5>
                </div>
                <div class="row g-4 mt-2">
                    <style>
                        .card {
                            border: none;
                            border-radius: 10px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                            transition: all 0.3s ease;
                            height: 100%;
                            display: flex;
                            flex-direction: column;
                            justify-content: space-between;
                        }

                        .card:hover {
                            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
                        }

                        .card-body {
                            background: #f8f9fa;
                            text-align: center;
                            flex-grow: 1;
                            display: flex;
                            flex-direction: column;
                            justify-content: center;
                            position: relative;
                            overflow: hidden;
                            z-index: 0;
                        }

                        .card-body::after {
                            content: '';
                            position: absolute;
                            top: 100%;
                            left: 0;
                            right: 0;
                            bottom: 0;
                            background: #52b3f885;
                            transition: top 1s ease;
                            z-index: 1;
                        }

                        .card-body:hover::after {
                            top: 0;
                        }

                        .card-body * {
                            position: relative;
                            z-index: 2;
                        }


                        .card-img {
                            padding: 10px;
                            display: flex;
                            justify-content: center;
                        }

                        .card-img img {
                            width: 110px;
                        }

                        .card-text {
                            flex-grow: 1;
                        }
                    </style>

                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/images/student.gif" class="card-img-top img-fluid "
                                    alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Student Management</h5>
                                <p class="card-text text-muted">Enables organizations to add and view student information, manage course enrollments.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/images/test.gif" class="card-img-top img-fluid " alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Test Management</h5>
                                <p class="card-text text-muted"> Provides tools for organizing, scheduling, and assigning tests to students.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">

                                <img src="./assets/images/admin.gif" class="card-img-top img-fluid " alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Admin Management</h5>
                                <p class="card-text text-muted">Allows organizations to assign distinct permissions, ensuring a secure and organized management structure.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">

                                <img src="./assets/images/monitoring.gif" class="card-img-top img-fluid "
                                    alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Real-Time Monitoring</h5>
                                <p class="card-text text-muted">Provides live tracking of student activity during exams, allowing admins to monitor students.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row g-4 mt-2">

                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">
                                <img src="./assets/images/scheduling.gif" class="card-img-top img-fluid "
                                    alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Automatic Exam Scheduling</h5>
                                <p class="card-text text-muted">Organizations can set up exams in advance with scheduled start and end times.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">

                                <img src="./assets/images/dashboard.gif" class="card-img-top img-fluid "
                                    alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Student Dashboard</h5>
                                <p class="card-text text-muted">A personalized dashboard for each student, where they can view assigned exams and access previous results.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">

                                <img src="./assets/images/score.gif" class="card-img-top img-fluid "
                                    alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Result Exporting</h5>
                                <p class="card-text text-muted">Organizations can analysis, and record-keeping for the future records.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="card">
                            <div class="card-img">

                                <img src="./assets/images/feedback.gif" class="card-img-top img-fluid "
                                    alt="...">
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">Feedback Collection</h5>
                                <p class="card-text text-muted">Enables students to provide feedback on exam.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="footer text-center py-3">
                &copy; 2024 Sk Tech Company. All Rights Reserved
            </div> -->
        </div>
    </div>
    <!-- contact_us and footer -->
    <?php include 'cont_us.php' ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            function loadStates() {
                $.ajax({
                    url: "get_states.php",
                    method: "GET",
                    success: function (data) {
                        $('#state').html(data);
                    },
                    error: function () {
                        $('#state').html('<option value="">Error Loading States</option>');
                    }
                });
            }

            loadStates();

            $('#state').change(function () {
                var state = $(this).val();
                if (state != '') {
                    $.ajax({
                        url: "get_districts.php",
                        method: "POST",
                        data: { state: state },
                        success: function (data) {
                            $('#district').html(data);
                        },
                        error: function () {
                            $('#district').html('<option value="">Error Loading Districts</option>');
                        }
                    });
                } else {
                    $('#district').html('<option value="">Select District</option>');
                }
            });
        });
    </script>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var currentStep = "<?php echo $_SESSION['step']; ?>";
            var stepToSection = {
                'verifyOtp': 'registration-form',
                'submitForm': 'registration-form'
            };
            var sectionId = stepToSection[currentStep];
            if (sectionId) {
                var section = document.getElementById(sectionId);
                if (section) {
                    section.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    </script>
    <script>
        let timer; 
        let timeRemaining = 30; 
        const resendBtn = document.getElementById('resendOtpBtn');
        const resendMessage = document.getElementById('resendMessage');

        function startTimer() {
            resendBtn.disabled = true; 
            resendBtn.innerText = `Resend OTP in (${timeRemaining})`;

            timer = setInterval(() => {
                timeRemaining--;

                if (timeRemaining < 0) {
                    clearInterval(timer); 
                    resendBtn.disabled = false; 
                    resendBtn.innerText = 'Resend OTP'; 
                    resendMessage.innerText = '';
                    timeRemaining = 30; 
                } else {
                    resendBtn.innerText = `Resend OTP in (${timeRemaining})`; 
                    resendBtn.style.color = '#000';
                }
            }, 1000);
        }

        function resetTimer() {
            clearInterval(timer); 
            timeRemaining = 30; 
            startTimer();
        }

        function showResendButton() {
            resendBtn.style.display = 'inline-block'; 
            resetTimer(); 
        }

        resendBtn.addEventListener('click', function () {
            resendMessage.innerText = 'OTP has been resent!'; 
            resetTimer(); 
        });

        showResendButton(); 
    </script>
    <script src="./assets/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>

</html>