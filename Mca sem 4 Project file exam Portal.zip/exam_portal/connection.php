<?php

$servername = "localhost";
$username = "formsub";
$password = "Form6@6sub*utk!^";
$dbname = "sumit-database";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (!mysqli_set_charset($conn, "utf8mb4")) {
    printf("Error loading character set utf8mb4: %s\n", mysqli_error($conn));
    exit();
}
?>
