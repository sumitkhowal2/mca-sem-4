<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "./header-link.php";

$exam_id = $_GET['exam_id'];
$std_id = $_GET['std_id'];

$result = $conn->query("SELECT answers_data FROM submit_exam WHERE test_id = $exam_id AND std_id = $std_id");

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $answer_data = json_decode($row['answers_data'], true);
    
    if (is_array($answer_data)) {
        
        $total_question = count($answer_data);
        $correct_answer = 0;
    
        foreach ($answer_data as $answer) {
            // Ensure both selected and correct answers are trimmed and lowercase for accurate comparison
            if (isset($answer['selected_answer'], $answer['correct_answer']) &&
                trim(strtolower($answer['selected_answer'])) === trim(strtolower($answer['correct_answer']))) {
                $correct_answer++;
            }
        }
        

        $wrong_answer = $total_question - $correct_answer;
        $score = ($total_question > 0) ? ($correct_answer / $total_question) * 100 : 0;
        $status = $score >= 50 ? 'Passed' : 'Failed';  
        $update_query = "UPDATE results
                         SET total_question = $total_question,
                             correct_answer = $correct_answer,
                             wrong_answer   = $wrong_answer,
                             score          = $score, 
                             status         = '$status', 
                             exam_date      = NOW()
                         WHERE test_id = $exam_id AND std_id = $std_id";
         if (!$conn->query($update_query)) {
            echo "Update query error: " . mysqli_error($conn);
        }
       
       if(mysqli_affected_rows($conn) === 0){

           $conn->query( "INSERT INTO results (test_id, std_id, total_question, correct_answer, wrong_answer, score, status, exam_date)
                  VALUES ($exam_id, $std_id, $total_question, $correct_answer, $wrong_answer, $score, '$status', NOW())");
        }
        
    } else {
        echo "No valid answer data found for this exam and student.";
    }
} else {
    echo "No exam record found or query failed.";
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Result</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
       

        .container {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
            text-align: center;
        }

        h2 {
            color: #333;
            font-weight: 700;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid #ddd;
        }

        th,
        td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #f4f6f9;
            color: #555;
        }

        td {
            background-color: #fff;
            color: #333;
        }

        .badge {
            display: inline-block;
            margin: 20px 0;
            padding: 10px 20px;
            font-size: 1.1rem;
            border-radius: 5px;
        }

        .badge.passed {
            background-color: #4caf50;
            color: #fff;
        }

        .badge.failed {
            background-color: #e53935;
            color: #fff;
        }

        .progress {
            width: 100%;
            height: 20px;
            background-color: #ddd;
            border-radius: 5px;
            margin: 20px 0;
        }

        .progress-bar {
            height: 100%;
            width:
                <?php echo $percentage; ?>
                %;
            background-color: #4caf50;
            border-radius: 5px;
        }

        .summary {
            color: #666;
            font-size: 0.9rem;
        }
    </style>
</head>

<body style="background:black">
    <div class="container-fluid d-flex justify-content-between bg-secondary p-2">
        <a href="index.php" class="btn btn-primary ">Home</a>
        <a href="logout.php" class="btn btn-danger ">Logout</a>

    </div>
    <div class="container mt-3">
        <h2>Exam Result</h2>

        <table>
            <tr>
                <th>Total Questions</th>
                <td><?php echo $total_question; ?></td>
            </tr>
            <tr>
                <th>Correct Answers</th>
                <td><?php echo $correct_answer; ?></td>
            </tr>
            <tr>
                <th>Wrong Answers </th>
                <td><?php echo $wrong_answer; ?></td>
            </tr>
           
            <tr>
                <th>Your Score</th>
                <td><?php echo $score; ?></td>
            </tr>
        </table>

        <?php if ($score >= 50): ?>
            <span class="badge passed">Congratulations, You Passed!</span>
        <?php else: ?>
            <span class="badge failed">Better Luck Next Time</span>
        <?php endif; ?>

        <p class="summary">Thank you for taking the exam. Your performance is reflected in the score.Keep improving!</p>
    </div>
</body>

</html>

