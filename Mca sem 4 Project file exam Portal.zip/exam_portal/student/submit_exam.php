<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "./header-link.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exam_data'])) {
    $examData = json_decode($_POST['exam_data'], true);

    if (!isset($examData['std_id'], $examData['test_id'], $examData['answers'], $examData['total_questions'])) {
        echo json_encode(['message' => 'Invalid data format.']);
        exit;
    }

    $std_id = $examData['std_id'];
    $test_id = $examData['test_id'];
    $answers = $examData['answers'];
    $submitted_at = date("Y-m-d H:i:s");

    $answersData = [];

    foreach ($answers as $question_id => $selected_answer) {
        $correctAnswerResult = $conn->query("SELECT answer FROM answer_sheet WHERE id = '$question_id' AND test_id = '$test_id'");
        $correctAnswerRow = $correctAnswerResult->fetch_assoc();
        $correct_answer = $correctAnswerRow['answer'];

        $answersData[] = [
            'question_id' => $question_id,
            'correct_answer' => $correct_answer,
            'selected_answer' => $selected_answer
        ];
    }

    $answersDataJSON = json_encode($answersData);
    $conn->query("UPDATE submit_exam
        SET answers_data = '$answersDataJSON',
            submitted_at = '$submitted_at'
        WHERE std_id = '$std_id' AND test_id = '$test_id'
    
    ");
    
    if(mysqli_affected_rows($conn) === 0){
        $conn->query("INSERT INTO submit_exam (std_id, test_id, answers_data, submitted_at) VALUES ('$std_id', '$test_id', '$answersDataJSON', '$submitted_at')");
    }

   
}
?>