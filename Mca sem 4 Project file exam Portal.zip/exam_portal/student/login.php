<?php
session_start();
include "../connection.php";
if (isset($_POST['login'])) {
    $mobile = $_POST['mobile'];
    $pass = $_POST['password'];

    if (empty($mobile) || empty($pass)) {
        $querystatus = "ERROR!! Please Fill the Fields";
    } else {
        $check = $conn->query("SELECT id, std_name , std_mobile, password FROM student_details WHERE std_mobile = '$mobile' AND password = '$pass'");
        if ($check->num_rows > 0) {
            $row = $check->fetch_assoc();
            $_SESSION['std_name'] = $row['std_name'];
            $_SESSION['std_id'] = $row['id'];
            echo "
            <script>
                window.location.href = 'index.php';
            </script>
            ";
            exit;
        } else {
            $querystatus = "ERROR!! Invalid Details";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STUDENT | LOGIN</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #0e1a35;
        }

        .login-container {
            background: #1f2a48;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            width: 300px;
            color: white;
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 20px;
            color: #ffffff;
        }

        .input-group {
            position: relative;
            margin-bottom: 30px;
        }

        .input-group input {
            width: 100%;
            padding: 10px;
            background: none;
            border: 1px solid #4f5b7a;
            border-radius: 5px;
            color: white;
            outline: none;
        }

        .input-group label {
            position: absolute;
            top: 10px;
            left: 10px;
            color: #808db1;
            pointer-events: none;
            transition: 0.2s ease all;
        }

        .input-group input:focus~label,
        .input-group input:not(:placeholder-shown)~label {
            top: -15px;
            left: 10px;
            font-size: 12px;
            color: #00aaff;
        }

        .actions button {
            width: 100%;
            padding: 10px;
            background: #00aaff;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .actions button:hover {
            background: #0077cc;
        }


        /* The snackbar - hidden by default */
        #snackbar {
            visibility: hidden;
            min-width: 250px;
            margin-left: -125px;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 5px;
            padding: 16px;
            position: fixed;
            z-index: 1;
            left: 50%;
            bottom: 30px;
            font-size: 17px;
        }

        /* Show the snackbar */
        #snackbar.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, fadeout 0.5s 2.5s;
        }

        @-webkit-keyframes fadein {
            from {
                bottom: 0;
                opacity: 0;
            }

            to {
                bottom: 30px;
                opacity: 1;
            }
        }

        @keyframes fadein {
            from {
                bottom: 0;
                opacity: 0;
            }

            to {
                bottom: 30px;
                opacity: 1;
            }
        }

        @-webkit-keyframes fadeout {
            from {
                bottom: 30px;
                opacity: 1;
            }

            to {
                bottom: 0;
                opacity: 0;
            }
        }

        @keyframes fadeout {
            from {
                bottom: 30px;
                opacity: 1;
            }

            to {
                bottom: 0;
                opacity: 0;
            }
        }
    </style>
</head>

<body>
    <div id="snackbar"></div>
   
    <div class="login-container">
        <h2>Student Login</h2>
        <form method="POST">
            <div class="input-group">
                <input type="tel" pattern="[0-9]{10}" name="mobile" title="Please enter a 10-digit phone number" id="mobile" required>
                <label for="mobile">Mobile</label>
            </div>
            <div class="input-group">
                <input type="password" name="password" id="password" required>
                <label for="password">Password</label>
            </div>
            <div class="actions">
            <button type="submit" name="login">Login</button>
            </div>
        </form>
    </div>

    <script>
        <?php if (isset($querystatus)): ?>
            var querystatus = "<?php echo $querystatus; ?>";
            showSnackbar(querystatus);
        <?php endif; ?>

        function showSnackbar(querystatus) {
            var parts = querystatus.split("&&");
            var message = parts[0];
            var redirectPath = parts[1];
            var snackbar = document.getElementById("snackbar");
            snackbar.innerHTML = message;
            snackbar.className = "show";
            setTimeout(function () {
                snackbar.className = snackbar.className.replace("show", "");
                if (redirectPath) {
                    window.location.href = redirectPath;
                }
            }, 3000);
        }
    </script>
</body>

</html>