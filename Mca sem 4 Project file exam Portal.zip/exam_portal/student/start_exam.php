<?php
include "./header-link.php";
$exam_assign_id = $_GET['exam_id'];

$examAssignResult = $conn->query("
  SELECT exam_assign_details.test_id , test_details.t_time , test_details.test_name
  FROM exam_assign_details  
  JOIN test_details ON exam_assign_details.test_id = test_details.id
  WHERE exam_assign_details.id = '$exam_assign_id'
");

if ($examAssignResult && $examAssignResult->num_rows > 0) {
    $row = $examAssignResult->fetch_assoc();
    $test_id = $row['test_id'];
    $t_time = $row['t_time'];
    $test_name = $row['test_name'];
    $result = $conn->query("SELECT * FROM answer_sheet WHERE test_id = '$test_id'");
    $questions = [];
    while ($row = $result->fetch_assoc()) {
        $questions[] = $row;
    }
} else {
    echo "No questions found for this exam assignment.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exam Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>

<body>
    <div class="exam-bg"></div>
    <div class="container-fluid header p-3">
        <div class="container d-flex justify-content-between align-items-center">
            <p class="fw-bold">Total Questions: <span id="total_qs"><?php echo count($questions); ?></span></p>
            <h5> <?php echo $test_name; ?></h5>
            <div><a href="javascript:void(0);" class="btn btn-dark" id="submit-exam-btn"
                    onclick="submitExam()">Submit</a></div>

        </div>
    </div>

    <div class="content-section">
        <div class="container mt-4 p-4 mb-4">
            <div class="question-section">
                <div class="ans-qs-sec">
                    <div class="cout-clock">
                        <span><i class="fa-solid fa-clock me-2"></i><span id="timer"></span></span>
                    </div>
                    <!-- Question Display Area -->
                    <div id="question-display"></div>

                    <!-- Navigation Buttons -->
                    <div class="buttons text-center">
                        <div class=" mt-4">
                            <button id="prev-btn" class="btn btn-primary" disabled><i
                                    class="fa-solid fa-arrow-left me-2"></i>Previous</button>
                            <button id="next-btn" class="btn btn-primary">Next<i
                                    class="fa-solid fa-arrow-right ms-2"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script>
        const questions = <?php echo json_encode($questions); ?>;
        let currentQuestionIndex = 0;
        const userAnswers = {};

        function displayQuestion(index) {
            const question = questions[index];
            const questionHtml = `
                <div class="question-text d-flex">
                    <span>Q- ${index + 1}</span>
                    <div class="qs ms-2">
                        <p><strong>${question.question}</strong></p>
                    </div>
                </div>
                <form>
                    <ul>
                        <li><input type="radio" name="answer[${question.id}]" value="${question.option1}" class="qoption" ${userAnswers[question.id] === "1" ? "checked" : ""}>
                            <span class="d-flex"><i>A)</i><p class="ms-2">${question.option1}</p></span>
                        </li>
                        <li><input type="radio" name="answer[${question.id}]" value="${question.option2}" class="qoption" ${userAnswers[question.id] === "2" ? "checked" : ""}>
                            <span class="d-flex"><i>B)</i><p class="ms-2">${question.option2}</p></span>
                        </li>
                        <li><input type="radio" name="answer[${question.id}]" value="${question.option3}" class="qoption" ${userAnswers[question.id] === "3" ? "checked" : ""}>
                            <span class="d-flex"><i>C)</i><p class="ms-2">${question.option3}</p></span>
                        </li>
                        <li><input type="radio" name="answer[${question.id}]" value="${question.option4}" class="qoption" ${userAnswers[question.id] === "4" ? "checked" : ""}>
                            <span class="d-flex"><i>D)</i><p class="ms-2">${question.option4}</p></span>
                        </li>
                    </ul>
                </form>
            `;
            document.getElementById("question-display").innerHTML = questionHtml;
            document.getElementById("prev-btn").disabled = index === 0;
            document.getElementById("next-btn").disabled = index === questions.length - 1;


            document.querySelectorAll(".qoption").forEach(option => {
                option.addEventListener("click", () => {
                    userAnswers[question.id] = option.value;
                });
            });
        }

        const initialTimeLeft = <?php echo $t_time; ?> * 60;

        function initializeCountdown() {
            const timerElement = document.getElementById("timer");
            let endTime;

            if (localStorage.getItem("examEndTime")) {
                endTime = parseInt(localStorage.getItem("examEndTime"), 10);

                if (isNaN(endTime)) {
                    endTime = Date.now() + initialTimeLeft * 1000;
                    localStorage.setItem("examEndTime", endTime);
                }
            } else {
                endTime = Date.now() + initialTimeLeft * 1000;
                localStorage.setItem("examEndTime", endTime);
            }

            const interval = setInterval(() => {
                const currentTime = Date.now();
                const timeLeft = Math.floor((endTime - currentTime) / 1000);

                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;

                if (timeLeft > 0) {
                    timerElement.textContent = `${minutes}:${seconds.toString().padStart(2, '0')}`;
                } else {
                    clearInterval(interval);
                    alert("Time is up! Your exam will be submitted.");
                    localStorage.removeItem("examEndTime");
                    document.getElementById("submit-exam-btn").click();
                }
            }, 1000);
        }

        displayQuestion(currentQuestionIndex);
        initializeCountdown();

        document.getElementById("next-btn").addEventListener("click", () => {
            if (currentQuestionIndex < questions.length - 1) {
                currentQuestionIndex++;
                displayQuestion(currentQuestionIndex);
            }
        });

        document.getElementById("prev-btn").addEventListener("click", () => {
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                displayQuestion(currentQuestionIndex);
            }
        });
    </script>
    <script>
        function submitExam() {
            if (!confirm('Are you sure to submit the exam?')) return;

            const submitData = {
                std_id: <?php echo $std_id; ?>,
                test_id: <?php echo $test_id; ?>,
                total_questions: questions.length,
                answers: {}

            };

            questions.forEach(question => {
                submitData.answers[question.id] = userAnswers[question.id] || null;
            });

            // console.log("submitData:", submitData);

            $.ajax({
                url: 'submit_exam.php',
                type: 'POST',
                data: { exam_data: JSON.stringify(submitData) },
                success: function (response) {
                    window.location.href = "result.php?exam_id=" + submitData.test_id + "&std_id=" + submitData.std_id;
                },
                error: function (xhr, status, error) {
                    alert("An error occurred during submission: " + error);
                }
            });
        }

    </script>
</body>

</html>