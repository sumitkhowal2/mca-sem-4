<?php
include "header-link.php";
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$exams = $conn->query("
    SELECT es.id , es.std_id, es.test_id, t.test_name 
    FROM exam_assign_details es 
    JOIN test_details t ON es.test_id = t.id
    WHERE es.std_id = '$std_id' AND es.status = 'active'
");
?>

<div class="container-fluid p-2 bg-primary d-flex justify-content-between">
    <span class="text-light fw-bold text-uppercase">Name: <?= htmlspecialchars($std_name) ?></span>
    <span class="text-light d-none d-lg-block" id="current-time"></span>
    <a href="./logout.php" class="btn btn-danger">Logout</a>
</div>

<div class="container mt-3 bg-light shadow rounded p-4">
    <h3 class="text-center">Assigned Exams</h3>

    <?php if ($exams->num_rows > 0): ?>
        <table class="table table-striped mt-3">
            <thead>
                <tr>
                    <th>Exam Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($exam = $exams->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($exam['test_name']) ?></td>
                        <td>
                            <button class="btn btn-success"
                                onclick="showExamModal(<?= $exam['id'] ?>, '<?= htmlspecialchars($exam['test_name']) ?>')">Start</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No exams assigned yet.</p>
    <?php endif; ?>
</div>

<!-- Modal for exam instructions -->
<div class="modal fade" id="examModal" tabindex="-1" role="dialog" aria-labelledby="examModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="examModalLabel">Exam Instructions</h5>

            </div>
            <div class="modal-body">
                <p>Please read the following instructions carefully before starting the exam:</p>
                <ul class="p-4">
                    <li>Do not navigate away from the test window during the exam.</li>
                    <li>Ensure you have a stable internet connection.</li>
                    <li>Once started, you cannot pause or restart the exam.</li>
                    <li>Do not navigate away from the test window during the exam.</li>
                    <li>Ensure you have a stable internet connection.</li>
                    <li>Once started, you cannot pause or restart the exam.</li>
                    <li>Do not navigate away from the test window during the exam.</li>
                    <li>Ensure you have a stable internet connection.</li>
                    <li>Once started, you cannot pause or restart the exam.</li>
                    <li>Do not navigate away from the test window during the exam.</li>
                    <li>Ensure you have a stable internet connection.</li>
                    <li>Once started, you cannot pause or restart the exam.</li>
                    <li>Do not navigate away from the test window during the exam.</li>
                    <li>Ensure you have a stable internet connection.</li>
                    <li>Once started, you cannot pause or restart the exam.</li>
                    <li>Do not navigate away from the test window during the exam.</li>
                    <li>Ensure you have a stable internet connection.</li>
                    <li>Once started, you cannot pause or restart the exam.</li>
                </ul>
                <div class=" mt-3">
                    <input type="checkbox" class="form-check-input me-2" id="termsCheckbox"
                        onclick="toggleProceedButton()">
                    <label class="form-check-label ms-2 text-primary text-decoration-underline" for="termsCheckbox">I
                        agree to the terms and conditions</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" id="proceedButton" class= "btn btn-primary" onclick="proceedToExam()"
                    disabled>Proceed</button>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
    let examId;

    function showExamModal(id, examName) {
        examId = id;
        document.getElementById('examModalLabel').innerText = "Exam Instructions - " + examName;
        document.getElementById('termsCheckbox').checked = false;
        document.getElementById('proceedButton').disabled = true;
        $('#examModal').modal('show');
    }

    function toggleProceedButton() {
        const isChecked = document.getElementById('termsCheckbox').checked;
        document.getElementById('proceedButton').disabled = !isChecked;
    }

    function proceedToExam() {
        window.location.href = "start_exam.php?exam_id=" + examId;
    }
  
    function updateTime() {
        const now = new Date();
        document.getElementById('current-time').innerHTML =
            "Time: " +
            String(now.getHours()).padStart(2, '0') + ":" +
            String(now.getMinutes()).padStart(2, '0') + ":" +
            String(now.getSeconds()).padStart(2, '0') + " , " +
            "Date: " + String(now.getDate()).padStart(2, '0') + "-" +
            String(now.getMonth() + 1).padStart(2, '0') + "-" +
            now.getFullYear();
    }
    setInterval(updateTime, 1000);
</script>