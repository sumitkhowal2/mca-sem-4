<?php
$conn->set_charset("utf8mb4");

if (isset($_POST['contsbmt'])) {
  $name = mysqli_real_escape_string($conn, $_POST['name']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);
  $subject = mysqli_real_escape_string($conn, $_POST['subject']);
  $msg = mysqli_real_escape_string($conn, $_POST['msg']);

  if (!empty($name) && !empty($email) && !empty($mobile) && !empty($subject) && !empty($msg)) {
    $sql = "INSERT INTO contact (name, email, mobile, subject, msg) VALUES ('$name', '$email', '$mobile', '$subject', '$msg')";
    
    if ($conn->query($sql) === TRUE) {
      $querystatus = "success&&Query Sent Successfully! We will contact you soon!&&index.php";
    } else {
      $querystatus = "error&&Failed: " . $conn->error . "&&index.php";
    }
  } else {
    $querystatus = "error&&Failed: All fields are required!&&index.php";
  }
}
?>

<style>
  ul {
    list-style: none;
  }

  input {
    overflow: hidden;
  }

  .section-title {
    position: relative;
    font-size: 30px;
    font-weight: 600;
    font-family: "Poppins", sans-serif;
    margin: 0 0 35px;
  }

  .sec-pad {
    padding: 60px 0 0;
    /* margin: 50px 0; */
  }

  .contact-sec {
    align-item: center;
    display: flex;
    background-color: #5cbde466;
  }

  .contact-sec .contact-ul li,
  .contact-ul b {
    font-size: 20px;
    margin: 10px 0;
    font-family: Cambria, Cochin, Georgia, Times, "Times New Roman", serif;
    word-wrap: break-word;
  }

  .contact-sec .contact-ul i {
    font-size: 18px;
    padding: 10px;
    margin-right: 10px;
    border-radius: 50%;
  }

  .contact-detail a {
    color: #000;
    text-decoration: none;
  }

  .contact-sec .contact-ul li b:hover {
    color: #f93;
  }

  .contact-sec .contact-ul li .fa-location-dot {
    color: #f44337;
    border: 2px solid #f4433790;
  }

  .contact-sec .contact-ul li .fa-phone {
    color: #00b055;
    border: 2px solid #00b05590;
  }

  .contact-sec .contact-ul li .fa-envelope {
    color: #ff6347;
    border: 2px solid #ff634790;
  }

  .contact-detail span {
    width: 400px;
    display: flex;
    justify-content: center;
  }

  .contact-detail span a {
    font-size: 20px;
    padding: 6px 12px;
    color: #000;
    border-radius: 50%;
    margin: 0px 5px;
  }

  .contact-detail span .fb {
    color: #3b5998;
    border: 3px solid #3b5998;
  }

  .contact-detail span .fb:hover {
    color: #fff;
    background-color: #3b5998;
  }

  .contact-detail span .insta {
    color: #833ab4;
    border: 3px solid #833ab4;
  }

  .contact-detail span .insta:hover {
    color: #fff;
    background-color: #833ab4;
  }

  .contact-detail span .twitter {
    color: #00acee;
    border: 3px solid #00acee;
  }

  .contact-detail span .twitter:hover {
    color: #fff;
    background-color: #00acee;
  }

  form.contFrm {
    max-width: 396px;
    margin: auto;
  }

  .inptFld {
    width: 100%;
    height: 50px;
    border: 0;
    margin: 0 0 10px;
    border-radius: 8px;
    padding: 0 20px;
    font-size: 16px;
    color: #000;
  }

  .inptFld:focus {
    outline-offset: -4px;
    outline: 1px solid #f93;
  }

  .contFrm textarea {
    height: 75px;
    padding-top: 5px;
  }

  .inptBtn {
    height: 50px;
    border: 0;
    background: #00b055;
    font-size: 14px;
    color: #fff;
    margin: auto;
    letter-spacing: 1px;
    cursor: pointer;
    width: 100%;
    max-width: 200px;
  }

  /* Responcive css Start */

  @media (max-width: 991px) {
    .sec-pad {
      padding: 20px 0 0px;
    }

    .contact-sec .contact-ul li,
    .contact-ul b {
      font-size: 18px;
    }

    .contact-sec .contact-ul i {
      font-size: 14px;
      padding: 6px;
      margin-right: 6px;
    }

    .inptFld {
      height: 40px;
      margin: 0 0 10px;
      padding: 0 14px;
      font-size: 14px;
    }
  }

  @media (max-width: 767px) {
    .contact-detail span {
      width: auto;
    }

    .contact-detail span a {
      font-size: 18px;
      padding: 5px 10px;
      color: #000;
      border-radius: 50%;
      margin: 0px 5px 20px;
    }
  }

  @media (max-width: 575px) {
    .section-title {
      font-size: 26px;
      font-weight: 500;
    }

    .contact-sec {
      border-radius: 10% 10% 0% 0% / 5% 5% 0% 0%;
    }

    .contact-sec .contact-ul i {
      border: none;
    }

    .inptFld {
      height: 36px;
      margin: 0 0 8px;
      padding: 0 14px;
      font-size: 14px;
    }
  }

  @media (max-width: 480px) {

    .contact-sec .contact-ul li,
    .contact-ul b {
      font-size: 16px;
    }
  }
</style>
</head>

<body>
  <div class="">
    <section class="contact-sec sec-pad">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="contact-detail">
              <h1 class="section-title">Contact us</h1>

              <ul class="contact-ul">
                <li><i class="fa fa-location-dot"></i> Runech Dham, Tanawada, Jodhpur</li>

                <li>
                  <i class="fa fa-phone"></i>
                  <a href="tel:+919887724031"><b>9887724031</b></a>,
                  <a href="tel:+9887724031"><b>9887724031</b></a>
                </li>

                <li>
                  <i class="fa-solid fa-envelope"></i>
                  <a href="mailto:sumitkhowal2@gmail.com"><b> sumitkhowal2@gmail.com</b></a>
                </li>
              </ul>

              <span>
                <a href="#" class="fb"><i class="fa-brands fa-facebook"></i></a>
                <a href="#" class="insta"><i class="fa-brands fa-instagram"></i></a>
                <a href="#" class="twitter"><i class="fa-brands fa-twitter"></i></a>
              </span>
            </div>
          </div>

          <div class="col-md-6">
            <form class="contFrm" method="POST">
              <div class="row">
                <div class="col-sm-6">
                  <input type="text" name="name" placeholder="Your Name" class="inptFld" required />
                </div>

                <div class="col-sm-6">
                  <input type="email" name="email" placeholder="Email Address" class="inptFld" required />
                </div>

                <div class="col-sm-6">
                  <input type="tel" pattern="\d{10}" title="Please enter 10 digit mobile number" name="mobile" placeholder="Phone Number" class="inptFld" required />
                </div>

                <div class="col-sm-6">
                  <input type="text" name="subject" placeholder="Subject" class="inptFld" required />
                </div>

                <div class="col-12">
                  <textarea class="inptFld" name="msg" rows="" cols="" placeholder="Your Message..." required></textarea>
                </div>

                <div class="col-12">
                  <input type="submit" name="contsbmt" value="SUBMIT" class="inptBtn" />
                </div>
              </div>
            </form>
          </div>
        </div>

        <div style="text-align: center; margin-top: 20px;">
          <p> Copyright &copy;
            <script>
              document.write(new Date().getFullYear());
            </script>
            All rights reserved | Sk Tech Company
          </p>
        </div>

      </div>
    </section>
  </div>
  <script type="text/javascript">
        <?php if (isset($querystatus)) { ?>
            var data = '<?= $querystatus ?>'
            data = data.split('&&');

            var title = data['0'];
            title = title.toLowerCase().replace(/\b[a-z]/g, function (letter) {
                return letter.toUpperCase();
            });
            Swal.fire(title, data['1'], data['0']).then(function () {
                window.location.href = data['2'];
            });
        <?php } ?>
    </script>