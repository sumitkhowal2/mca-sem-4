<?php
include 'header.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['delete_id'])) {
    $student_id = $_GET['delete_id'];

    $update_sql = "UPDATE student_details SET status = 'inactive' WHERE id = $student_id";
    // $delete_sql = "DELETE FROM student_details WHERE id = $student_id";
    if (mysqli_query($conn, $update_sql)) {
        echo "<script>
            window.location.href = 'view-student.php';
        </script>";
    } else {
        echo "<script>alert('Failed to Update student');</script>";
    }
}

if($role == 'admin'){
    $sql = "SELECT s.id, s.std_name, s.std_mobile, c.course_name AS batch   FROM student_details s JOIN course_details c ON s.batch_id = c.id WHERE  s.status = 'active'"; 

}else{
    $sql = "SELECT s.id, s.std_name, s.std_mobile, c.course_name AS batch   FROM student_details s JOIN course_details c ON s.batch_id = c.id WHERE s.admin_id = $admin_id AND s.status = 'active'"; 

}

$result = mysqli_query($conn, $sql);

?>


    <div class="content">
        
        <div class="container mt-4">
            <h3>Student Details</h3>
            <div class="mb-3 text-end">
                <a href="import-student-file.php" class="btn btn-success">
                    <i class="fa fa-upload"></i> Import Students
                </a>
            </div>
            <table id="studentTable" class="table table-bordered table-hover mt-4">
                <thead class="table-dark">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Student Mobile</th>
                        <th>Course Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $srNo = 1;
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['id'];
                            echo "<tr>
                                    <td>{$srNo}</td>
                                    <td>{$row['id']}</td>
                                    <td>{$row['std_name']}</td>
                                    <td>{$row['std_mobile']}</td>
                                    <td>{$row['batch']}</td>
                                    <td class='d-flex justify-content-center'>
                                        <a href='edit-student.php?id={$id}' class='me-3'> <i class='fa fa-edit fa-edit'></i></a>
                                        <a href='view-student.php?delete_id={$id}' ><i class='fa fa-trash-o text-danger'></i></a>
                                    </td>
                                  </tr>";
                            $srNo++;
                        }
                    } else {
                        echo "<tr><td colspan='5'>No data found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>


<script>
    $(document).ready(function () {
        $('#studentTable').DataTable();
    });
</script>

<?php include "footer.php"; ?>
