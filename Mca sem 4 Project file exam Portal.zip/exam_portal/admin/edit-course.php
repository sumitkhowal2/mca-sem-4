<?php
include 'header.php';

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>window.location.href = 'view-course.php';</script>";
    exit();
}

$course_id = intval($_GET['id']);

$sql = "SELECT * FROM course_details WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $course_id);
$stmt->execute();
$result = $stmt->get_result();
$course = $result->fetch_assoc();
$stmt->close();

if (!$course) {
    echo "<script>window.location.href = 'view-course.php';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_course'])) {
    $updated_course_name = trim($_POST['course_name']);
    $updated_status = $_POST['status'];

    if (!empty($updated_course_name)) {
        $sql_update = "UPDATE course_details SET course_name = ?, status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update);
        $stmt->bind_param("ssi", $updated_course_name, $updated_status, $course_id);
        $stmt->execute();
        $stmt->close();

        echo "<script>window.location.href = 'view-course.php';</script>";
        exit();
    }
}
?>


    <div class="content">
        <div class="container mt-4">
            <h3>Edit Course</h3>
            <div class="edit-course-form shadow bg-light rounded p-3 mt-3">
                <form method="post" action="">
                    <div class="form-group">
                        <div class="row">
                            <div class="col-lg-5">
                                <label for="course_name">Course Name</label>
                                <input type="text" class="form-control" name="course_name" id="course_name"
                                    value="<?php echo htmlspecialchars($course['course_name']); ?>" required>

                            </div>
                            <div class="col-lg-4">
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <select class="form-control" name="status" id="status" required>
                                        <option value="active" <?php if ($course['status'] == 'active')
                                            echo 'selected'; ?>>Active</option>
                                        <option value="inactive" <?php if ($course['status'] == 'inactive')
                                            echo 'selected'; ?>>Inactive</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="text-end mt-4">
                        <button type="submit" name="update_course" class="btn btn-primary">Update Course</button>
                        <a href="view-course.php" class="btn btn-secondary">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>


<?php include 'footer.php'; ?>