<?php
include "header.php";
include "../connection.php";
error_reporting(E_ALL);
ini_set('display_errors', 1);
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id'])) {
    $courseId = $_POST['id'];
    echo ("course id: " .$courseId);
    $stmt = $conn->prepare("UPDATE course_details SET status = 'inactive' WHERE id = ?");
    $stmt->bind_param("i", $courseId);

    if ($stmt->execute()) {

    } else {

    }

    $stmt->close();
    header("Location: view-course.php");

} else {
    header("Location: view-course.php");

}
?>