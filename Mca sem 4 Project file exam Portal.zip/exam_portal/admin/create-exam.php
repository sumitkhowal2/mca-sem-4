<?php
include 'header.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$sql = "SELECT * FROM test_details WHERE status = 'active'";
$result = $conn->query($sql);

if (isset($_POST['createTest'])) {

    $std_id = $_POST['std_id'];
    $test_id = $_POST['exam'];

    if (empty($std_id) || empty($test_id)) {
        $querystatus = "error&&Please fill the fields&&create-exam.php";
    } else {
        $checkStudent = $conn->query("SELECT id FROM student_details WHERE id = '$std_id' AND status = 'active'");
        if($checkStudent->num_rows>0){
            $conn->query("INSERT INTO exam_assign_details (admin_id, std_id, test_id) VALUES ('$admin_id', '$std_id', '$test_id')");
            $querystatus = "success&&Exam Assign to the student&&create-exam.php";
        }else{
            $querystatus = "error&&Student Does not exists!!&&create-exam.php";
        }
    }

}
?>

<div class="content">
    <div class="container mt-4">
        <h3>Create Exam</h3>
        <hr>
        <div class="card p-3 rounded  exam-form mt-3">
            <form method="POST">
                <div class="row">
                    <div class="col-lg-4 col-12">
                        <label for="std_id" class="form-label">Enter Student ID</label>
                        <input type="number" class="form-control" name="std_id" placeholder="Enter Student ID" required autofocus>
                    </div>
                    <div class="col-12 col-lg-4 mb-3">
                        <label for="exam" class="form-label">Select Exam</label>
                        <select class="form-select" name="exam" id="exam" required>
                            <option value="">Select Exam</option>
                            <?php 
                            if ($result->num_rows >0){
                                while($row = $result->fetch_assoc()){
                                    echo '<option value="' . $row["id"] . '">' . $row["test_name"] . '</option>';
                                }
                            }else {
                                echo '<option value="">No Tests Available</option>';
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="text-end">
                    <input type="submit" name="createTest" value="Create Exam" class="btn btn-primary">
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php' ?>