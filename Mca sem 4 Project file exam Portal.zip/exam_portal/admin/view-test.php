<?php
include 'header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_test'])) {
    $test_id = intval($_POST['test_id']);

    $update_sql = $conn->prepare("UPDATE test_details SET status='inactive' WHERE id=?");
    if ($update_sql) {
        $update_sql->bind_param("i", $test_id);
        if ($update_sql->execute()) {
            // showSweetAlert('Success', 'Test marked as inactive successfully.', 'success');
        } else {
            showSweetAlert('Error', 'Failed to mark test as inactive.', 'error');
        }
        $update_sql->close();
    } else {
        showSweetAlert('Database Error', 'Failed to prepare the statement.', 'error');
    }
}

function showSweetAlert($title, $text, $icon, $redirect = '') {
    echo "<script>
        swal({
            title: '$title',
            text: '$text',
            icon: '$icon',
            button: 'OK',
        }).then(function() {
            if ('$redirect' !== '') {
                window.location.href = '$redirect';
            } else {
                // Reload the page to reflect changes
                window.location.reload();
            }
        });
    </script>";
    exit();
}

if($role == 'admin'){
    $sql = "SELECT * FROM test_details";
}else{

    $sql = "SELECT * FROM test_details WHERE admin_id = $admin_id";
}
$result = $conn->query($sql);

// Handle Success and Error Messages from Redirect
$alert_type = '';
$alert_title = '';
$alert_text = '';

if (isset($_GET['status'])) {
    if ($_GET['status'] === 'success') {
        $alert_type = 'success';
        $alert_title = 'Success';
        $alert_text = 'Answer sheet uploaded successfully.';
    } elseif ($_GET['status'] === 'error') {
        $alert_type = 'error';
        $alert_title = 'Error';
        $alert_text = 'There was an error uploading the answer sheet.';
    } elseif ($_GET['status'] === 'warning') {
        $alert_type = 'warning';
        $alert_title = 'Warning';
        $alert_text = 'No valid data found in the CSV file.';
    }
}
?>
    

    <div class="content">
        <div class="container mt-4">
            <h3 class="mt-4">View Test Details</h3>
            <div class=" mt-3">
                <table id="testDetailsTable" class="table table-bordered table-hover mt-4">
                    <thead class="table-dark">
                        <tr>
                            <th>S.No.</th>
                            <th>Test Name</th>
                            <th>Start Date</th>
                            <th>Total Time</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            $sr_no = 1;
                            while ($row = $result->fetch_assoc()) {
                                $test_id = htmlspecialchars($row['id']);
                                $test_name = htmlspecialchars($row['test_name']);
                                $strt_date = htmlspecialchars($row['strt_date']);
                                $t_time = htmlspecialchars($row['t_time']);
                                $status = htmlspecialchars(ucfirst($row['status']));

                                echo "<tr>
                                        <td>{$sr_no}</td>
                                        <td>{$test_name}</td>
                                        <td>{$strt_date}</td>
                                        <td>{$t_time}</td>
                                        <td>{$status}</td>
                                        <td class='d-flex justify-content-center align-items-center'>
                                            <a href='edit-test.php?id={$test_id}' class='me-2' title='Edit Test'><i class='fa fa-edit fa-edit'></i></a>
                                             <a href='import-test-file.php?test_id={$test_id}' class='' title='Import Answer Sheet'>
                                                <i class='fa fa-upload me-2 text-primary'></i> 
                                            </a>
                                            <form method='POST' action='' style='display:inline;'>
                                                <input type='hidden' name='test_id' value='{$test_id}'>
                                                <button type='submit' name='delete_test' class='border-0' title='Mark as Inactive' onclick=\"return confirm('Are you sure you want to mark this test as inactive?');\"><i class='fa fa-trash-o text-danger'></i></button>
                                            </form>
                                        </td>
                                        
                                      </tr>";
                                $sr_no++;
                            }
                        } else {
                            echo "<tr><td colspan='10' class='text-center'>No records found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>




<script>
$(document).ready(function () {
    $('#testDetailsTable').DataTable();

    <?php if ($alert_type && $alert_title && $alert_text): ?>
        swal({
            title: '<?php echo $alert_title; ?>',
            text: '<?php echo $alert_text; ?>',
            icon: '<?php echo $alert_type; ?>',
            button: 'OK',
        });
    <?php endif; ?>
});
</script>
<?php include "footer.php"; ?>

