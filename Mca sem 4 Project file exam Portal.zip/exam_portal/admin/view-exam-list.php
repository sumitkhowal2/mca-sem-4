<?php
include 'header.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['update'])) {
    $test_id = $_GET['update'];

    $update_sql=   "UPDATE exam_assign_details SET status = 'inactive' WHERE test_id = $test_id";
    
    if (mysqli_query($conn, $update_sql)) {
        echo "<script>
            window.location.href = 'view-exam-list.php';
        </script>";
    } else {
        echo "<script>alert('Failed to Update student');</script>";
    }
}

if($role == 'admin'){
    $sql = "SELECT
     s.id,
     s.std_name, 
     s.std_mobile,
     td.test_name,
     es.status,
     es.test_id   
     FROM student_details s 
     JOIN exam_assign_details es ON s.id = es.std_id 
     JOIN test_details td ON es.test_id = td.id
     "; 
   

}else{
    $sql = "SELECT
     s.id,
     s.std_name, 
     s.std_mobile,
     td.test_name,
     es.status,
     es.test_id  
     FROM student_details s 
     JOIN exam_assign_details es ON s.id = es.std_id 
     JOIN test_details td ON es.test_id = td.id
     WHERE s.admin_id = $admin_id "; 

}

$result = mysqli_query($conn, $sql);

?>


    <div class="content">
        
        <div class="container mt-4">
            <h3>View Assign Exam</h3>
            <table id="viewExamTable" class="table table-bordered table-hover mt-4">
                <thead class="table-dark">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Student Id</th>
                        <th>Student Name</th>
                        <th>Student Mobile</th>
                        <th>Exam Name</th>
                        <th>Test ID</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $srNo = 1;
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $id = $row['id'];
                            echo "<tr>
                                    <td>{$srNo}</td>
                                    <td>{$row['id']}</td>
                                    <td>{$row['std_name']}</td>
                                    <td>{$row['std_mobile']}</td>
                                    <td>{$row['test_name']}</td>
                                    <td>{$row['test_id']}</td>
                                    <td>{$row['status']}</td>
                                    
                                    <td class='d-flex justify-content-center'>
                                        <a href='edit-exam-list.php?id={$row['test_id']}' class='me-3'> <i class='fa fa-edit fa-edit'></i></a>
                                        <a href='view-exam-list.php?update={$row['test_id']}' ><i class='fa fa-trash-o text-danger'></i></a>
                                    </td>
                                  </tr>";
                            $srNo++;
                        }
                    } else {
                        echo "<tr><td colspan='5'>No data found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>


<script>
    $(document).ready(function () {
        $('#viewExamTable').DataTable();
    });
</script>

<?php include "footer.php"; ?>
