<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include "../connection.php";
if (!isset($_SESSION['mobile'])) {
	header("Location: login.php");
	exit();
}
$admin_id = $_SESSION['admin_id'];
$adminName = $_SESSION['admin_name'];
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendors/styles/style.css">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
	<style>
		.left-side-bar {
			transition: left 0.3s ease;
		}

		.left-side-bar.active {
			left: 0;
			transition: left 0.3s ease;
		}

		.menu-icon {
			cursor: pointer;
		}

		@media (min-width: 768px) {
			.left-side-bar {
				left: 0;
			}

			.main {
				margin: 15% 2%;
			}
		}

		.main {
			margin: 10% 2%;
		}

		.menusub li {
			padding: 10px !important;
			/* background: #6587a1; */
			margin-bottom: 8px;
			border-radius: 20px;
			margin-top: 8px;

		}

		.menusub li a {
			color: #fff;
			font-weight: 500;
		}

		.no-drop {
			display: block;
			padding: 18px 15px 18px 67px;
			font-size: 16px;
			color: #fff;
			font-weight: 300;
			letter-spacing: .03em;
			position: relative;
			font-family: 'Inter', sans-serif;
			-webkit-transition: all .3s ease-in-out;
			transition: all .3s ease-in-out;
		}

		.no-drop-icon {
			position: absolute;
			left: 10px;
			width: 42px;
			height: 42px;
			font-size: 24px;
			display: -webkit-box;
			display: -ms-flexbox;
			display: flex;
			-webkit-box-align: center;
			-ms-flex-align: center;
			align-items: center;
			-webkit-box-pack: center;
			-ms-flex-pack: center;
			justify-content: center;
			color: #fff;
			background-color: transparent;
			top: 50%;
			text-align: center;
			border-radius: 4px;
			-webkit-transition: all .3s ease-in-out;
			transition: all .3s ease-in-out;
			-webkit-transform: translate(0, -50%);
			transform: translate(0, -50%);
		}
	</style>
</head>

<body>
	<div class="container-fluid">
		<div class="header">
			<div class="header-left">
				<div class="menu-icon dw dw-menu"></div>
			</div>
			<div class="header-right">
				<div class="user-info-dropdown">
					<div class="dropdown">
						<a class="dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
							<span class="user-icon">
								<img src="vendors/images/admin_img.jpg" alt="">
							</span>
							<span
								class="user-name fw-bold text-uppercase"><?php echo htmlspecialchars($adminName); ?></span>
						</a>
						<ul class="dropdown-menu dropdown-menu-end dropdown-menu-icon-list">
							<li><a class="dropdown-item" href="profile.php"><i class="dw dw-user1"></i> Profile</a></li>
							<li><a class="dropdown-item" href="logout.php"><i class="dw dw-logout"></i> Log Out</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-2">
				<div class="left-side-bar">
					<div class="brand-logo">
						<a href="index.php">
							<h5 class="text-center text-light fst-italic">Hello,Admin</h5>
						</a>
						<div class="close-sidebar" data-bs-toggle="left-sidebar-close">
							<i class="ion-close-round"></i>
						</div>
					</div>
					<div class="menu-block customscroll">
						<div class="sidebar-menu">
							<ul id="accordion-menu">
								<li class="dropdown">
									<a href="index.php" class="no-drop">
										<span class="micon dw dw-home no-drop-icon"></span><span
											class="mtext">Dashboard</span>
									</a>
								</li>
								<?php if ($role == "admin") { ?>
									<li class="dropdown">
										<a href="#" class="dropdown-toggle" data-bs-toggle="collapse"
											data-bs-target="#manage-course-submenu">
											<span class="micon dw dw-user-1"></span><span class="mtext">Manage Course</span>
										</a>
										<ul id="manage-course-submenu" class="collapse menusub">
											<li>
												<a href="add-course.php" class="d-flex align-items-center">
													<i class="fa fa-user fs-5 text-light ms-2 me-2"></i> Add Course
												</a>
											</li>
											<li>
												<a href="view-course.php" class="d-flex align-items-center">
													<i class="fa fa-eye text-light fs-5 ms-2 me-2"></i> View Course
												</a>
											</li>
										</ul>
									</li>
								<?php } ?>

								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-bs-toggle="collapse"
										data-bs-target="#manage-student-submenu">
										<span class="micon dw dw-user-1"></span><span class="mtext">Manage
											Student</span>
									</a>
									<ul id="manage-student-submenu" class="collapse menusub">
										<li>
											<a href="add-student.php" class="d-flex align-items-center">
												<i class="fa fa-user fs-5 text-light ms-2 me-2"></i> Add Student
											</a>
										</li>
										<li>
											<a href="view-student.php" class="d-flex align-items-center">
												<i class="fa fa-eye text-light fs-5 ms-2 me-2"></i> View Student
											</a>
										</li>
									</ul>
								</li>

								<li class="dropdown">
									<a href="#" class="dropdown-toggle" data-bs-toggle="collapse"
										data-bs-target="#manage-test-submenu">
										<span class="micon dw dw-book-1"></span><span class="mtext">Manage Test</span>
									</a>
									<ul id="manage-test-submenu" class="collapse menusub">
										<li>
											<a href="add-test.php" class="d-flex align-items-center">
												<i class="fa fa-book fs-5 text-light ms-2 me-2"></i> Add Test
											</a>
										</li>
										<li>
											<a href="view-test.php" class="d-flex align-items-center">
												<i class="fa fa-eye fs-5 text-light ms-2 me-2"></i> View Test
											</a>
										</li>
									</ul>
								</li>
								<li class="dropdown">

									<a href="logout.php" class="no-drop" style="">
										<span class="micon dw dw-logout no-drop-icon" style=""></span><span
											class="mtext">Logout</span>
									</a>
								</li>
							</ul>

						</div>
					</div>
				</div>
			</div>