<?php
include 'header.php';

if (isset($_POST['importStd'])) {
    $file = $_FILES['std_file'];

    if ($file['error'] === UPLOAD_ERR_OK) {
        $fileType = pathinfo($file['name'], PATHINFO_EXTENSION);
        if ($fileType !== 'csv') {
            echo "<script>
                alert('Only .csv files are allowed');
            </script>";
        } else {
            $filePath = $file['tmp_name'];
            if (($handle = fopen($filePath, 'r')) !== FALSE) {
                $header = fgetcsv($handle, 1000, ','); 
                if ($header[0] !== 'name' || $header[1] !== 'mobile' || $header[2] !== 'batch_id') {
                    echo "<script>
                        alert('Invalid CSV format. Please ensure the headers are: name, mobile, batch_id.');
                    </script>";
                } else {
                    $success = true;
                    while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                        $std_name = $data[0];
                        $std_mobile = $data[1];
                        $batch = $data[2];

                        $batch_check_query = "SELECT id FROM course_details WHERE id = '$batch' AND status = 'active'";
                        $batch_check_result = mysqli_query($conn, $batch_check_query);

                        if (mysqli_num_rows($batch_check_result) > 0) {
                            $sql = "INSERT INTO student_details (std_name, std_mobile, batch_id, admin_id) VALUES ('$std_name', '$std_mobile', '$batch', '$admin_id')";
                            if (!mysqli_query($conn, $sql)) {
                                $success = false;
                            }
                        } else {
                            echo "<script>
                                alert('Batch ID $batch does not exist or is not active.');
                            </script>";
                            $success = false;
                            break; 
                        }
                    }
                    fclose($handle);

                    if ($success) {
                        echo "<script>
                            alert('Students added successfully.');
                            window.location = 'view-student.php';
                        </script>";
                    } else {
                        echo "<script>
                            alert('Failed to import some students.');
                        </script>";
                    }
                }
            } else {
                echo "<script>
                    alert('Failed to open the uploaded file');
                </script>";
            }
        }
    } else {
        echo "<script>
            alert('Error uploading file');
        </script>";
    }
}
?>

<div class="content">
    <div class="container mt-4">
        <div class="import shadow p-3 bg-light rounded">
            <h5 class="text-center">Import Student File</h5>
            <hr>
            <div class="import-form mt-3">
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-12 col-lg-6 mb-3">
                            <label for="std_file" class="form-label">Select File</label>
                            <div>
                                <input type="file" class="form-control mb-2" name="std_file" required>
                                <a href="./src/files/sample-student-file.csv" class="" download="sample-student-file.csv">Click here to Download Sample File</a>
                            </div>
                        </div>
                        <div class="text-end">
                            <input type="submit" name="importStd" value="Import File" class="btn btn-primary">
                            <a href="view-student.php" class="btn btn-secondary">Back</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include "footer.php"; ?>
