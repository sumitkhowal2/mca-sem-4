<?php
include 'header.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['id'])) {
    $test_id = intval($_GET['id']); // Sanitize input

    // Fetch student details, current status, and test name
    $sql = "SELECT 
                sd.std_name, 
                sd.std_mobile, 
                es.status, 
                td.test_name 
            FROM student_details sd 
            JOIN exam_assign_details es ON sd.id = es.std_id 
            JOIN test_details td ON es.test_id = td.id 
            WHERE es.test_id = $test_id";

    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $student = mysqli_fetch_assoc($result);
        $current_status = $student['status'];
        $current_test_name = $student['test_name'];
    } else {
        echo "<script>alert('Invalid Test ID or Data Not Found!'); window.location.href = 'view-student.php';</script>";
        exit;
    }

    // Fetch all other active exams from test_details
    $active_exams_sql = "SELECT id, test_name FROM test_details WHERE status = 'active'";
    $active_exams_result = mysqli_query($conn, $active_exams_sql);
}

// Handle form submission
if (isset($_POST['updateStd'])) {
    $status = $_POST['status'];
    $new_test_id = intval($_POST['test_id']);

    // Update query
    $update_sql = "UPDATE exam_assign_details 
                   SET status = '$status', test_id = $new_test_id 
                   WHERE test_id = $test_id";

    if (mysqli_query($conn, $update_sql)) {
        echo "<script>alert('Details updated successfully!'); window.location.href = 'view-exam-list.php';</script>";
    } else {
        echo "<script>alert('Failed to update details.');</script>";
    }
}
?>

<div class="content">
    <div class="container mt-4">
        <h3>Edit Assign Exam Details</h3>
        <div class="edit-course-form shadow bg-light rounded p-3 mt-3">
            <form method="POST" action="">
                <div class="row student-row">
                    <div class="col-3 col-lg-3 mb-3">
                        <label for="std_name" class="form-label">Student Name</label>
                        <input type="text" class="form-control" id="std_name" name="std_name"
                            value="<?php echo htmlspecialchars($student['std_name']); ?>" readonly required>
                    </div>

                    <div class="col-3 col-lg-3 mb-3">
                        <label for="std_mobile" class="form-label">Student Mobile</label>
                        <input type="text" class="form-control" id="std_mobile" name="std_mobile"
                            value="<?php echo htmlspecialchars($student['std_mobile']); ?>" readonly required>
                    </div>
                    
                    <div class="col-3 col-lg-3 mb-3">
                        <label for="test_id" class="form-label">Select Exam</label>
                        <select class="form-select" id="test_id" name="test_id" required>
                            <option value="<?php echo $test_id; ?>" selected>
                                <?php echo htmlspecialchars($current_test_name); ?>
                            </option>
                            <?php
                            if ($active_exams_result && mysqli_num_rows($active_exams_result) > 0) {
                                while ($exam = mysqli_fetch_assoc($active_exams_result)) {
                                    // Skip the current exam to avoid duplication in the dropdown
                                    if ($exam['id'] != $test_id) {
                                        echo "<option value='{$exam['id']}'>" . htmlspecialchars($exam['test_name']) . "</option>";
                                    }
                                }
                            }
                            ?>
                        </select>
                    </div>

                    <div class="col-3 col-lg-3 mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" name="status" required>
                            <option value="active" <?php echo ($current_status === 'active') ? 'selected' : ''; ?>>
                                Active</option>
                            <option value="inactive" <?php echo ($current_status === 'inactive') ? 'selected' : ''; ?>>
                                Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="text-end mt-4">
                    <button type="submit" name="updateStd" class="btn btn-primary">Update Student</button>
                    <a href="view-exam-list.php" class="btn btn-secondary">Back</a>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
