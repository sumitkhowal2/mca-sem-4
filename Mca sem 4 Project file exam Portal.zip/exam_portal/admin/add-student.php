<?php
include 'header.php'; 

$sql = "SELECT id, course_name FROM course_details WHERE status = 'active'";
$result = $conn->query($sql);

$batches = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $batches[$row['id']] = $row['course_name']; 
    }
}

if (isset($_POST['addStd'])) {
    $students = $_POST['students'];
    $admin_id = $_POST['admin_id'];
    $success = true;

    foreach ($students as $student) {
        // Use prepared statements to prevent SQL injection
        $std_name = mysqli_real_escape_string($conn, $student['name']);
        $std_mobile = mysqli_real_escape_string($conn, $student['mobile']);
        $batch_id = mysqli_real_escape_string($conn, $student['batch_id']); 

        if (empty($batch_id)) {
            echo "Error: batch_id is empty for student: $std_name<br>";
            $success = false;
            continue; 
        }

        $sql = "INSERT INTO student_details (std_name, std_mobile, batch_id, admin_id, password) VALUES ('$std_name', '$std_mobile', '$batch_id', '$admin_id', '$std_mobile')";
        $result = mysqli_query($conn, $sql);

        if (!$result) {
            echo "Database Insert Error: " . mysqli_error($conn) . "<br>";
            $success = false;
        }
    }

    if ($success) {
        $_SESSION['message'] = [
            'title' => 'Success!',
            'text' => 'Students Added Successfully',
            'type' => 'success'
        ];
    } else {
        $_SESSION['message'] = [
            'title' => 'Error!',
            'text' => 'Failed to Add Some Students',
            'type' => 'error'
        ];
    }

    // Redirect to the same page to display the message
    echo "<script>window.location.href = 'view-student.php';</script>";
    exit();
}

if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    // Use addslashes to escape any quotes in the message
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                title: '".addslashes($message['title'])."',
                text: '".addslashes($message['text'])."',
                icon: '".addslashes($message['type'])."',
                confirmButtonText: 'OK'
            });
        });
    </script>";
    unset($_SESSION['message']);
}
?>

<!-- HTML Form for Adding Students -->

    <div class="content">
        <div class="container mt-4">
            <div class="shadow p-3 bg-light rounded">
                <h5 class="text-center">Add Students</h5>
                <hr>
                <div class="profile-form mt-3">
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="admin_id" value="<?php echo htmlspecialchars($_SESSION['admin_id']); ?>">

                        <div id="studentFields">
                            <div class="row student-row">
                                <div class="col-3 col-lg-3 mb-3">
                                    <label for="std_name" class="form-label">Student Name</label>
                                    <input type="text" class="form-control" placeholder="Enter Student Name" name="students[0][name]" required>
                                </div>
                                <div class="col-3 col-lg-3 mb-3">
                                    <label for="std_mobile" class="form-label">Student Mobile</label>
                                    <input type="tel" class="form-control" placeholder="Enter Student Phone Number" name="students[0][mobile]" pattern="[0-9]{10}" title="Please enter a 10-digit mobile number" required>                                </div>
                                <div class="col-3 col-lg-2 mb-3">
                                    <label for="batch" class="form-label">Select Batch</label>
                                    <select class="form-select" name="students[0][batch_id]" required>
                                        <option value="">Select Batch</option>
                                        <?php foreach ($batches as $id => $batch): ?>
                                            <option value="<?php echo htmlspecialchars($id); ?>"><?php echo htmlspecialchars($batch); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-3 col-lg-1 mb-3" style="display: flex;align-items: center;justify-content: center;">
                                    <img src="./vendors/images/add.png" class="add-button img-fluid" width="20px" style="cursor:pointer;" alt="add">
                                </div>
                            </div>
                        </div>
                        <div class="text-end">
                            <input type="submit" name="addStd" value="Add Students" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<!-- JavaScript for Dynamic Form Fields -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        let studentCount = 1;

        document.getElementById('studentFields').addEventListener('click', function (e) {
            if (e.target.classList.contains('add-button')) {
                const newRow = document.createElement('div');
                newRow.className = 'row student-row';
                newRow.innerHTML = `
                    <div class="col-3 col-lg-3 mb-3">
                        <label for="std_name" class="form-label">Student Name</label>
                        <input type="text" class="form-control" placeholder="Enter Student Name" name="students[${studentCount}][name]" required>
                    </div>
                    <div class="col-3 col-lg-3 mb-3">
                        <label for="std_mobile" class="form-label">Student Mobile</label>
                        <input type="tel" class="form-control" placeholder="Enter Student Phone Number" pattern="[0-9]{10}" name="students[${studentCount}][mobile]" required>
                    </div>
                    <div class="col-3 col-lg-2 mb-3">
                        <label for="batch" class="form-label">Select Batch</label>
                        <select class="form-select" name="students[${studentCount}][batch_id]" required>
                            <option value="">Select Batch</option>
                            <?php foreach ($batches as $id => $batch): ?>
                                <option value="<?php echo htmlspecialchars($id); ?>"><?php echo htmlspecialchars($batch); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-3 col-lg-1 mb-3" style="display: flex;align-items: center;justify-content: center;">
                        <img src="./vendors/images/minus.png" class="remove-button img-fluid" width="20px" style="cursor:pointer;" alt="remove">
                    </div>
                `;
                document.getElementById('studentFields').appendChild(newRow);
                studentCount++;
            }

            if (e.target.classList.contains('remove-button')) {
                const row = e.target.closest('.student-row');
                if (row) {
                    row.remove();
                }
            }
        });
    });
</script>

<?php include "footer.php"; ?>
