<?php
include 'header.php';

$sql = "SELECT id, course_name FROM course_details WHERE status = 'active'";
$result = $conn->query($sql);

$batches = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $batches[$row['id']] = $row['course_name']; 
    }
}

$admin_id = $_SESSION['admin_id']; 

if (isset($_POST['addtest'])) {
    $batch_id = intval($_POST['batch']);
    $test_name = trim($_POST['test_name']);
    $strt_date = $_POST['strt_date'];
    // $end_date = $_POST['end_date'];
    // $rslt_date = $_POST['rslt_date'];
    // $pt_mrk = floatval($_POST['pt_mrk']);
    // $ng_mrk = floatval($_POST['ng_mrk']);
    $t_time = $_POST['t_time'];
    $created_at = date('Y-m-d H:i:s');
    $status = 'active';

    $errors = [];
    if (empty($test_name)) {
        $errors[] = "Test name is required.";
    }
    if (empty($strt_date)) {
        $errors[] = "All date fields are required.";
    }
   

    if (empty($errors)) {
        $query = "INSERT INTO test_details (admin_id, batch_id, test_name, strt_date, t_time, status, created_at) 
                  VALUES ('$admin_id', '$batch_id', '$test_name', '$strt_date', '$t_time', '$status', '$created_at')";

        if ($conn->query($query) === TRUE) {
            echo '<script>
                    Swal.fire({
                        title: "Success!",
                        text: "Test added successfully!",
                        icon: "success",
                        confirmButtonText: "OK"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location.href = "view-test.php"; // Redirect to the same page
                        }
                    });
                  </script>';
        } else {
            echo '<script>
                    Swal.fire({
                        title: "Error!",
                        text: "There was an error adding the test. Please try again.",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                  </script>';
        }
    } else {
        foreach ($errors as $error) {
            echo '<script>
                    Swal.fire({
                        title: "Error!",
                        text: "' . htmlspecialchars($error) . '",
                        icon: "error",
                        confirmButtonText: "OK"
                    });
                  </script>';
        }
    }
}
?>


    <div class="content">
        <div class="container mt-4">
            <div class="add-test shadow p-3 bg-light rounded">
                <h5 class="text-center fw-bold">Create Exam(about exam)</h5>
                <hr>
                <div class="test-form mt-3">
                    <form method="POST" action="" enctype="multipart/form-data">
                        <div class="row">
                            <!-- Select Batch -->
                            <div class="col-12 col-lg-3 mb-3">
                                <label for="batch" class="form-label">Select Batch</label>
                                <select class="form-select" name="batch" id="batch" required>
                                    <option value="">Select Batch</option>
                                    <?php foreach ($batches as $id => $batch): ?>
                                        <option value="<?php echo htmlspecialchars($id); ?>"><?php echo htmlspecialchars($batch); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Test Name -->
                            <div class="col-12 col-lg-3 mb-3">
                                <label for="test_name" class="form-label">Exam Name</label>
                                <input type="text" class="form-control" id="test_name" name="test_name" placeholder="Enter Test Name" required>
                            </div>

                            <!-- Start Date -->
                            <div class="col-6 col-lg-3 mb-3">
                                <label for="strt_date" class="form-label">Exam Date</label>
                                <input type="date" class="form-control" id="strt_date" name="strt_date" required>
                            </div>

                            <!-- End Date -->
                            <!-- <div class="col-6 col-lg-3 mb-3">
                                <label for="end_date" class="form-label">End Date</label>
                                <input type="date" class="form-control" id="end_date" name="end_date" required>
                            </div> -->

                            <!-- Result Date -->
                            <!-- <div class="col-6 col-lg-3 mb-3">
                                <label for="rslt_date" class="form-label">Result Date</label>
                                <input type="date" class="form-control" id="rslt_date" name="rslt_date" required>
                            </div> -->

                            <!-- Positive Mark -->
                            <!-- <div class="col-6 col-lg-3 mb-3">
                                <label for="pt_mrk" class="form-label">Positive Mark</label>
                                <input type="number"  class="form-control" id="pt_mrk" name="pt_mrk" placeholder="Enter Positive Mark" required>
                            </div> -->

                            <!-- Negative Mark -->
                            <!-- <div class="col-6 col-lg-3 mb-3">
                                <label for="ng_mrk" class="form-label">Negative Mark</label>
                                <input type="number"  class="form-control" id="ng_mrk" name="ng_mrk" placeholder="Enter Negative Marks" required>
                            </div> -->
                            <!-- total time -->
                            <div class="col-6 col-lg-3 mb-3">
                                <label for="t_time" class="form-label">Total Time</label>
                                <input type="number"  class="form-control" name="t_time" placeholder="Enter Total Time" required>
                            </div>
                        </div>
                        <div class="text-end">
                            <input type="submit" name="addtest" value="Add Exam" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php include "footer.php"; ?>
