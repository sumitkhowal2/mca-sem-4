<?php
session_start();
include "../connection.php";
$alert = '';
if (!isset($_SESSION['step'])) {
    $_SESSION['step'] = 'sendOtp';
}

if (isset($_POST['back'])) {
    unset($_SESSION['mobile'], $_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['otp_enabled']);
    $_SESSION['step'] = 'sendOtp'; 
}

if (isset($_POST['login'])) {
    $mobile = mysqli_real_escape_string($conn, $_POST['mobile']);

    $sql = "SELECT * FROM org_details WHERE mobile = '$mobile'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $admin_id = $row['id'];
        $adminName = $row['owner_name'];
        // $role = $row['role'];
        $otp = rand(1000, 9999);
        $sql_update = "UPDATE org_details SET otp = '$otp', otp_generated_at = NOW() WHERE mobile = '$mobile'";
        mysqli_query($conn, $sql_update);
        $_SESSION['mobile'] = $row['mobile'];
        $_SESSION['admin_id'] = $admin_id;
        $_SESSION['admin_name'] = $adminName;
        // $_SESSION['role'] = $role;

        $msg = "Use " . $otp . " as one time password(OTP). From Utkarsh Classes";
        $message_content = urlencode($msg);
        $apiUrl = "http://www.smscountry.com/SMSCwebservice_Bulk.aspx?User=nirmal.gahlot&passwd=k2X0d8eQV4UK&mobilenumber={$mobile}&message={$message_content}&sid=UTKRSH&mtype=N&DR=Y";

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);

        $_SESSION['otp_enabled'] = true;

        $alert = 'Swal.fire({
            title: "Success!",
            text: "OTP sent successfully!",
            icon: "success",
            confirmButtonText: "OK"
        });';
        $_SESSION['step'] = 'verifyOtp';
    } else {
        $alert = 'Swal.fire({
            title: "Error!",
            text: "Invalid Mobile Number",
            icon: "error",
            confirmButtonText: "OK"
        });';
    }
}
if (isset($_POST['back'])) {
    unset($_SESSION['mobile'], $_SESSION['admin_id'], $_SESSION['admin_name'], $_SESSION['otp_enabled']);
    $_SESSION['step'] = 'sendOtp';
}

if (isset($_POST['resendOtp'])) {
    $newOtp = rand(1000, 9999);
    $_SESSION['otp'] = $newOtp;

    $mobile = $_SESSION['mobile'];
    $stmt = $conn->prepare("UPDATE org_details SET otp = ?, otp_generated_at = NOW() WHERE mobile = ?");
    $stmt->bind_param("ss", $newOtp, $mobile);

    if ($stmt->execute()) {
        $alert = 'Swal.fire({
            title: "Success!",
            text: "OTP Resent successfully!",
            icon: "success",
            confirmButtonText: "OK"
        });';
        // echo "<script>showSnackbar('OTP has been resent to your mobile number.');</script>";

        $msg = "Use " . $newOtp . " as one time password(OTP). From Utkarsh Classes";
        $message_content = urlencode($msg);
        $apiUrl = "http://www.smscountry.com/SMSCwebservice_Bulk.aspx?User=nirmal.gahlot&passwd=k2X0d8eQV4UK&mobilenumber={$mobile}&message={$message_content}&sid=UTKRSH&mtype=N&DR=Y";

        $ch = curl_init($apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
    } else {
        echo "Error updating OTP: " . $conn->error;
    }

    $stmt->close();
}

if (isset($_POST['verify_otp'])) {
    if (!isset($_SESSION['mobile'])) {
        $alert = 'Swal.fire({
            title: "Error!",
            text: "Session expired. Please login again.",
            icon: "error",
            confirmButtonText: "OK"
        }).then(() => {
            window.location.href = "login.php";
        });';
        exit;
    }

    $mobile = $_SESSION['mobile'];
    $otp = mysqli_real_escape_string($conn, $_POST['otp']);
    // echo $otp;
    $sql = "SELECT * FROM org_details WHERE mobile = '$mobile' AND otp = '$otp'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['loggedin'] = true;
        header("Location: index.php");
        exit;
    } else {
        $alert = 'Swal.fire({
            title: "Error!",
            text: "Invalid OTP",
            icon: "error",
            confirmButtonText: "OK"
        });';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Login</title>
    <link rel="icon" type="image/x-icon" href="../assets/images/utkarsh_fevicon.png">
    <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html,
        body {
            height: 100%;
        }

        .bg-img {
            background-image: url('./vendors/images/back.jpeg');
            height: 100%;
            background-position: center;
            background-repeat: no-repeat;
            background-size: cover;
            filter: blur(8px);
            -webkit-filter: blur(8px);
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: -1;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background: rgba(0, 0, 0, 0.4);
            z-index: -1;
        }

        .login-container {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .loginForm {
            width: 100%;
            max-width: 400px;
            /* background-color: rgba(255, 216, 73, 0.95); */
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.3);
        }

        .logo img {
            width: 100px;
            margin-bottom: 20px;
        }

        @media (max-width: 576px) {
            .loginForm {
                padding: 20px;
            }

            .logo img {
                width: 80px;
            }
        }
    </style>
</head>

<body>
    <div class="bg-img"></div>
    <div class="overlay"></div>

    <div class="container login-container">
        <div class="loginForm shadow rounded">
        <?php if ($_SESSION['step'] == 'verifyOtp'): ?>
            <div class="verifyOtp" id="verifyOtp">
               <div class="text-end mb-3">
                        <form action="" method="POST" style="display: inline;">
                        <i class="fa fa-arrow-left" aria-hidden="true"></i>
                         <input type="submit" name="back" value="Back" class="border-0 text-decoration-underline bg-transparent">
                        </form>
                    </div>
                </div>
            <?php endif;?>

            <div class="logo text-center">
                <img src="./vendors/images/logo-2.png"  alt="SK Tech" class="rounded mb-2">
            </div>
            <h3 class="text-center  mb-4">ADMIN LOGIN</h3>

            <?php if ($_SESSION['step'] == 'sendOtp'): ?>
                <div class="sendOtp" id="sendOtp">
                    <form action="" method="POST">
                        <div class="form-group mb-3">
                            <label for="mobile" class="form-label fw-bold">Enter Mobile Number</label>
                            <input type="tel" pattern="[0-9]{10}" name="mobile" id="mobile" class="form-control"
                                placeholder="Enter Mobile Number" autofocus required>
                        </div>
                        <div class="mt-3 text-center">
                            <input type="submit" name="login" class="btn btn-dark px-4" value="Send OTP">
                        </div>
                    </form>
                </div>
            <?php endif; ?>

            <?php if ($_SESSION['step'] == 'verifyOtp'): ?>
                <div class="verifyOtp" id="verifyOtp">
                    <form action="" method="POST">
                        <div class="form-group mb-3">
                            <label for="otp" class="form-label fw-bold">Enter OTP</label>
                            <input type="text" name="otp" id="otp" class="form-control" placeholder="Enter OTP" required>
                        </div>
                        <div class="mt-3 text-center">
                            <input type="submit" name="verify_otp" class="btn btn-dark px-4" value="Verify OTP">
                        </div>

                    </form>
                    <div class="text-center mt-2">
                        <form action="" method="POST">
                            <button type="submit" id="resendOtpBtn" class="border-0" style="display:none;background:none;"name="resendOtp">Resend OTP</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script>
        let timer; 
        let timeRemaining = 30; 
        const resendBtn = document.getElementById('resendOtpBtn');
        const resendMessage = document.getElementById('resendMessage');

        function startTimer() {
            resendBtn.disabled = true; 
            resendBtn.innerText = `Resend OTP in (${timeRemaining})`;

            timer = setInterval(() => {
                timeRemaining--;

                if (timeRemaining < 0) {
                    clearInterval(timer);
                    resendBtn.disabled = false; 
                    resendBtn.innerText = 'Resend OTP'; 
                    resendMessage.innerText = '';
                    timeRemaining = 30; 
                } else {
                    resendBtn.innerText = `Resend OTP in (${timeRemaining})`; 
                    resendBtn.style.color = '#000';
                }
            }, 1000); 
        }

        function resetTimer() {
            clearInterval(timer);
            timeRemaining = 30; 
            startTimer(); 
        }

        function showResendButton() {
            resendBtn.style.display = 'inline-block'; 
            resetTimer(); 
        }

        resendBtn.addEventListener('click', function () {
            resendMessage.innerText = 'OTP has been resent!'; 
            resetTimer(); 
        });

        showResendButton(); 

        
    </script>
    <script>
        <?php if ($_SESSION['step'] == 'verifyOtp'): ?>
                $("#otp").focus();
            <?php endif; ?>
        </script>
    <script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    
    <?php if ($alert): ?>
        <script>
            <?php echo $alert; ?>
        </script>
    <?php endif; ?>
</body>

</html>