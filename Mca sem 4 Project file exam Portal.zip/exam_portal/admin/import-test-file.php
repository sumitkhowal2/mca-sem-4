<?php
include 'header.php';

function setSweetAlert($title, $text, $icon, $redirect)
{
    $_SESSION['alert'] = [
        'title' => $title,
        'text' => $text,
        'icon' => $icon
    ];

    echo "<script>window.location.href = '$redirect';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_GET['test_id'])) {
        setSweetAlert('Error', 'Test ID is missing.', 'error', 'view-test.php');
    }
    $test_id = intval($_GET['test_id']);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['test_id'])) {
        setSweetAlert('Error', 'Test ID is missing.', 'error', 'view-test.php');
    }
    $test_id = intval($_POST['test_id']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['importStd'])) {
    if (isset($_FILES['std_file']) && $_FILES['std_file']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['std_file']['tmp_name'];
        $fileName = $_FILES['std_file']['name'];
        $fileSize = $_FILES['std_file']['size'];
        $fileType = $_FILES['std_file']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = array('csv');
        if (in_array($fileExtension, $allowedfileExtensions)) {
            if (($handle = fopen($fileTmpPath, "r")) !== FALSE) {
                $conn->begin_transaction();

                try {
                    // Prepare the SQL statement
                    $insert_sql = $conn->prepare("INSERT INTO answer_sheet (test_id, question, option1, option2, option3, option4, answer) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    if (!$insert_sql) {
                        throw new Exception('Failed to prepare the insert statement.');
                    }

                    // Fetch and validate header
                    $header = fgetcsv($handle, 1000, ",");
                    if ($header === FALSE) {
                        throw new Exception('CSV file is empty.');
                    }

                    // Check for expected headers
                    $expectedHeaders = ['question', 'option1', 'option2', 'option3', 'option4', 'answer'];
                    $header = array_map('strtolower', $header);
                    if ($header !== $expectedHeaders) {
                        throw new Exception('CSV headers do not match the expected format.');
                    }

                    $rowCount = 0;
                    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                        if (count($data) < 6) {
                            continue;
                        }

                        $question = trim($data[0]);
                        $option1 = trim($data[1]);
                        $option2 = trim($data[2]);
                        $option3 = trim($data[3]);
                        $option4 = trim($data[4]);
                        $answer = trim($data[5]);

                        // Validation to ensure data isn't empty
                        if (empty($question) || empty($option1) || empty($option2) || empty($option3) || empty($option4) || empty($answer)) {
                            continue;
                        }

                        // Bind parameters and execute insertion
                        $insert_sql->bind_param("issssss", $test_id, $question, $option1, $option2, $option3, $option4, $answer);
                        if (!$insert_sql->execute()) {
                            throw new Exception('Failed to insert data: ' . $insert_sql->error);
                        }

                        $rowCount++;
                    }

                    $conn->commit();
                    fclose($handle);
                    $insert_sql->close();

                    if ($rowCount > 0) {
                        setSweetAlert('Success', "Answer sheet uploaded successfully with {$rowCount} entries.", 'success', "import-test-file.php?test_id={$test_id}");
                    } else {
                        setSweetAlert('Warning', 'No valid data found in the CSV file.', 'warning', "import-test-file.php?test_id={$test_id}");
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    fclose($handle);
                    error_log($e->getMessage(), 3, "error_log.txt");
                    setSweetAlert('Error', 'There was an error processing the CSV file.', 'error', "import-test-file.php?test_id={$test_id}");
                }
            } else {
                setSweetAlert('Error', 'Unable to open the uploaded CSV file.', 'error', "import-test-file.php?test_id={$test_id}");
            }
        } else {
            setSweetAlert('Invalid File Type', 'Only CSV files are allowed.', 'error', "import-test-file.php?test_id={$test_id}");
        }
    } else {
        setSweetAlert('File Upload Error', 'No file uploaded or there was an upload error.', 'error', "import-test-file.php?test_id={$test_id}");
    }
}

$test_sql = "SELECT * FROM test_details WHERE id = {$test_id}";
$test_result = $conn->query($test_sql);
if ($test_result->num_rows > 0) {
    $test = $test_result->fetch_assoc();
} else {
    setSweetAlert('Error', 'Test not found.', 'error', 'view-test.php');
}

$ans_sql = "SELECT * FROM answer_sheet WHERE test_id = {$test_id}";
$ans_result = $conn->query($ans_sql);
?>

<div class="content">
    <div class="container mt-4 mb-3">
        <div class="import shadow p-3 bg-light rounded mt-4">
            <h5 class="text-center">Import Answer Sheet for Test:
                <?php echo htmlspecialchars($test['test_name']); ?> (ID: <?php echo htmlspecialchars($test_id); ?>)
            </h5>
            <hr>
            <div class="import-form mt-3">
                <form method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" name="test_id" value="<?php echo htmlspecialchars($test_id); ?>">
                    <div class="row">
                        <div class="col-12 col-lg-6 mb-3">
                            <label for="std_file" class="form-label">Select CSV File</label>
                            <div>
                                <input type="file" class="form-control mb-2" name="std_file" id="std_file" required
                                    accept=".csv">
                                <a href="./src/files/sample-test-file.csv" class=""
                                    download="sample-test-file.csv">Click here to Download Sample File</a>
                            </div>
                        </div>
                        <div class="text-end col-12">
                            <input type="submit" name="importStd" value="Import File" class="btn btn-primary">
                            <a href="view-test.php" class="btn btn-secondary">Back</a>
                        </div>
                    </div>
                </form>
                <div class="mt-3">

                </div>
            </div>
        </div>

        <!-- Display Existing Answer Sheet Data -->
        <div class="mt-5">
            <?php if ($ans_result->num_rows > 0): ?>
                <div class="answer-sheet-data">
                    <h5>Existing Answer Sheet Entries</h5>
                    <div class="table-responsive mt-3">
                        <table id="answerSheetTable" class="table table-bordered table-hover table-striped display nowrap"
                            style="width:100%">
                            <thead class="table-dark">
                                <tr>
                                    <th>S.No.</th>
                                    <th>Question</th>
                                    <th>Option1</th>
                                    <th>Option2</th>
                                    <th>Option3</th>
                                    <th>Option4</th>
                                    <th>Answer</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $ans_sr_no = 1;
                                while ($row = $ans_result->fetch_assoc()) {
                                    echo "<tr>
                                                <td>{$ans_sr_no}</td>
                                                <td>{$row['question']}</td>
                                                <td>{$row['option1']}</td>
                                                <td>{$row['option2']}</td>
                                                <td>{$row['option3']}</td>
                                                <td>{$row['option4']}</td>
                                                <td>{$row['answer']}</td>
                                              </tr>";
                                    $ans_sr_no++;
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info" role="alert">
                    Sheet Not Uploaded.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>



<script>
    $(document).ready(function () {
        <?php if ($ans_result->num_rows > 0): ?>
            $('#answerSheetTable').DataTable({
                "scrollX": true,
                "pageLength": 10,
                "lengthMenu": [5, 10, 20, 50],
                "language": {
                    "emptyTable": "No answer sheet entries available."
                }
            });
        <?php endif; ?>

        <?php
        if (isset($_SESSION['alert'])) {
            $alert = $_SESSION['alert'];
            $alert_title = htmlspecialchars($alert['title'], ENT_QUOTES, 'UTF-8');
            $alert_text = htmlspecialchars($alert['text'], ENT_QUOTES, 'UTF-8');
            $alert_icon = htmlspecialchars($alert['icon'], ENT_QUOTES, 'UTF-8');
            unset($_SESSION['alert']);
            echo "swal({
            title: '{$alert_title}',
            text: '{$alert_text}',
            icon: '{$alert_icon}',
            button: 'OK',
        });";
        }
        ?>
    });
</script>
<?php include "footer.php"; ?>