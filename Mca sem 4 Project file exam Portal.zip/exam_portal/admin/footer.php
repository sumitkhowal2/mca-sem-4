
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css">


<!-- sweetalert function for all common alerts -->
<script type="text/javascript">
        <?php if (isset($querystatus)) { ?>
            var data = '<?= $querystatus ?>'
            data = data.split('&&');

            var title = data['0'];
            title = title.toLowerCase().replace(/\b[a-z]/g, function (letter) {
                return letter.toUpperCase();
            });
            Swal.fire(title, data['1'], data['0']).then(function () {
                window.location.href = data['2'];
            });
        <?php } ?>
    </script>
<script>
    document.getElementById('toggleSidebar').addEventListener('click', function() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('active');
        document.querySelector('.main').classList.toggle('active'); // Adjust main content margin
    });
</script>
</body>

</html>








<!-- </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css">

	<script>
		document.addEventListener('DOMContentLoaded', function () {
  const menuIcon = document.querySelector('.dw.dw-menu');
  const sidebar = document.querySelector('.left-side-bar');
  const closeButton = document.querySelector('.close-sidebar'); 

  menuIcon.addEventListener('click', function () {
    sidebar.classList.toggle('active');
  });

  closeButton.addEventListener('click', function () { 
    sidebar.classList.remove('active'); 
  });
});
	</script>

</body>

</html> -->