<?php
include "header.php";


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $course_id = intval($_POST['id']);

    $sql_update = "UPDATE course_details SET status = 'inactive' WHERE id = ?";

    if ($stmt = $conn->prepare($sql_update)) {
        $stmt->bind_param("i", $course_id);
        if ($stmt->execute()) {
            // echo "<div class='alert alert-success'>Course marked as inactive successfully.</div>";
        } else {
            // echo "<div class='alert alert-danger'>Error marking course as inactive.</div>";
        }
        $stmt->close();
    }
}

$sql = "SELECT * FROM course_details";
$result = $conn->query($sql);

?>


<div class="content">
    <div class="container mt-4">
        <h3>Course Details</h3>
        <table id="courseTable" class="table table-bordered table-hover mt-4">
            <thead class="table-dark">
                <tr>
                    <th>Sr. No.</th>
                    <th>Course Name</th>
                    <th>Status</th>
                    <th>Created On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $srNo = 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $srNo++ . "</td>";
                        echo "<td>" . htmlspecialchars($row['course_name']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['created_at']) . "</td>";
                        echo "<td class='d-flex justify-content-center'>
                                       <a href='edit-course.php?id=" . $row['id'] . "' class='me-2'><i class='fa fa-edit fa-edit'></i></a>                                  
                                         <form action='' method='post' style='display:inline;'>
                                        <input type='hidden' name='id' value='" . $row['id'] . "'>
                                        <button type='submit' class='border-0 bg-light' onclick='return confirm(\"Are you sure you want to mark this course as inactive?\");'><i class='fa fa-trash-o text-danger'></i></button>
                                    </form>
                                  </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5' class='text-center'>No courses found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    $(document).ready(function () {
        $('#courseTable').DataTable();

    });

</script>

<?php include "footer.php"; ?>