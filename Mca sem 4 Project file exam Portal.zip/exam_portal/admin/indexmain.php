<?php
include 'header.php';

if($role == 'admin'){
	$student_sql = "SELECT * FROM student_details";
	$test_sql = "SELECT * FROM test_details";
}else{
	$student_sql = "SELECT * FROM student_details WHERE admin_id = $admin_id";
	$test_sql = "SELECT * FROM test_details WHERE admin_id = $admin_id";
}
$total_students = mysqli_num_rows(mysqli_query($conn, $student_sql));
$total_tests = mysqli_num_rows(mysqli_query($conn, $test_sql));
?>
<div class="col-lg-10">
	<div class="main">
		<div class="container">
			<h3>Welcome to Dashboard</h3>
			<div class="row mt-2">
				<div class="col-lg-3">
					<a href="view-student.php">
					<div class="card p-3 border-0 shadow">
						<div class="d-flex">
							<img src="../assets/images/student-management.png" class="rounded-circle border" width="30%" alt="student">
							<div class="ms-2">
								<h4><?php echo $total_students; ?></h4>
								<span class="text-secondary">Total Students</span>
							</div>
						</div>
					</div>
					</a>
				</div>
				<div class="col-lg-3">
					<a href="view-test.php">
					<div class="card p-3 shadow border-0">
						<div class="d-flex">
							<img src="../assets/images/test-management.png" class="rounded-circle border"  width="30%" alt="student">
							<div class="ms-2">
								<h4><?php echo $total_tests; ?></h4>
								<span class="text-secondary">Total Tests</span>
							</div>
						</div>
					</div>
					</a>
				</div>
			</div>
		</div>

	</div>
</div>

<?php include "footer.php"; ?>