<?php
include 'header.php';


if (isset($_GET['id'])) {
    $student_id = intval($_GET['id']); 

    $sql = "SELECT std_name, std_mobile, batch_id FROM student_details WHERE id = $student_id";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $student = mysqli_fetch_assoc($result);
    } else {
        echo "<script>
                alert('No student found with the given ID');
                window.location.href = 'display-students.php';
              </script>";
        exit();
    }

    $course_sql = "SELECT id, course_name FROM course_details WHERE status = 'active'";
    $course_result = mysqli_query($conn, $course_sql);
    $courses = [];
    if ($course_result && mysqli_num_rows($course_result) > 0) {
        while ($course = mysqli_fetch_assoc($course_result)) {
            $courses[] = $course;
        }
    } else {
        echo "<script>
                alert('No active courses available');
                window.location.href = 'display-students.php';
              </script>";
        exit();
    }
} else {
    echo "<script>
            alert('No ID provided');
            window.location.href = 'display-students.php';
          </script>";
    exit();
}

if (isset($_POST['updateStd'])) {
    $std_name = mysqli_real_escape_string($conn, trim($_POST['std_name']));
    $std_mobile = mysqli_real_escape_string($conn, trim($_POST['std_mobile']));
    $batch_id = intval($_POST['batch_id']);

    if (empty($std_name) || empty($std_mobile) || empty($batch_id)) {
        echo "<script>alert('All fields are required');</script>";
    } else {
        $update_sql = "UPDATE student_details SET std_name = ?, std_mobile = ?, batch_id = ? WHERE id = ?";
        $stmt = mysqli_prepare($conn, $update_sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssii", $std_name, $std_mobile, $batch_id, $student_id);
            if (mysqli_stmt_execute($stmt)) {
                echo "<script>
                        alert('Student details updated successfully');
                        window.location.href = 'view-student.php';
                      </script>";
            } else {
                echo "<script>
                        alert('Failed to update student details: " . mysqli_error($conn) . "');
                      </script>";
            }
            mysqli_stmt_close($stmt);
        } else {
            echo "<script>
                    alert('Failed to prepare the update statement');
                  </script>";
        }
    }
}
?>


    <div class="content">
        <div class="container mt-4">
            <h3>Edit Student Details</h3>
            <div class="edit-course-form shadow bg-light rounded p-3 mt-3">
            <form method="POST" action="">
                <div class="row student-row">
                    <div class="col-3 col-lg-3 mb-3">
                        <label for="std_name" class="form-label">Student Name</label>
                        <input type="text" class="form-control" id="std_name" name="std_name"
                            value="<?php echo htmlspecialchars($student['std_name']); ?>" required>
                    </div>

                    <div class="col-3 col-lg-3 mb-3">
                        <label for="std_mobile" class="form-label">Student Mobile</label>
                        <input type="text" class="form-control" id="std_mobile" name="std_mobile"
                            value="<?php echo htmlspecialchars($student['std_mobile']); ?>" required>
                    </div>

                    <div class="col-3 col-lg-3 mb-3">
                        <label for="batch_id" class="form-label">Batch</label>
                        <select class="form-select" id="batch_id" name="batch_id" required>
                            <option value="">Select Batch</option>
                            <?php
                            foreach ($courses as $course) {
                                $selected = ($course['id'] == $student['batch_id']) ? 'selected' : '';
                                echo "<option value='" . htmlspecialchars($course['id']) . "' $selected>" . htmlspecialchars($course['course_name']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="text-end mt-4">
                <button type="submit" name="updateStd" class="btn btn-primary">Update Student</button>
                <a href="view-student.php" class="btn btn-secondary">Back</a>
                </div>
            </form>
        </div>
        </div>
    </div>


<?php include 'footer.php'; ?>
