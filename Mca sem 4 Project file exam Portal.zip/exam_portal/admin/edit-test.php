<?php
include 'header.php';


if (isset($_GET['id'])) {
    $test_id = $_GET['id'];

    $stmt = $conn->prepare("SELECT * FROM test_details WHERE id = ?");
    $stmt->bind_param("i", $test_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $current_batch_id = $row['batch_id'];
        $current_status = $row['status'];
    } else {
        echo "<script>
            swal('Test not found', {icon: 'error'}).then(function() {
                window.location = 'view-test.php';
            });
        </script>";
        exit();
    }
} else {
    echo "<script>
        swal('Invalid Test ID', {icon: 'error'}).then(function() {
            window.location = 'view-test.php';
        });
    </script>";
    exit();
}

if (isset($_POST['update_test'])) {
    $batch = $_POST['batch'];
    $test_name = $_POST['test_name'];
    $strt_date = $_POST['strt_date'];
    // $end_date = $_POST['end_date'];
    // $rslt_date = $_POST['rslt_date'];
    // $pt_mrk = $_POST['pt_mrk'];
    // $ng_mrk = $_POST['ng_mrk'];
    $t_time = $_POST['t_time'];
    $status = $_POST['status'];

    $sql = "UPDATE test_details SET 
        batch_id = '$batch', 
        test_name = '$test_name', 
        strt_date = '$strt_date', 
        t_time = '$t_time',
        status = '$status'
        WHERE id = $test_id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
             
            window.location.href = 'view-test.php';
        </script>";
    } else {
        echo "<script>swal('Failed to Update Test', {icon: 'error'});</script>";
    }
}

$batches_sql = "SELECT id, course_name FROM course_details";
$batches_result = $conn->query($batches_sql);

if (!$batches_result) {
    echo "<script>
        swal('Failed to fetch batches', {icon: 'error'}).then(function() {
            window.location = 'view-test.php';
        });
    </script>";
    exit();
}
?>


<div class="content">
    <div class="container mt-4">
        <h3>Edit Test</h3>
        <div class="edit-test shadow p-3 mt-2 bg-light rounded">
            <form method="POST" action="">
                <div class="row">
                    <!-- Batch Selection -->
                    <div class="col-12 col-lg-3 mb-3">
                        <label for="batch" class="form-label">Select Batch</label>
                        <select class="form-select" name="batch" required>
                            <option value="">Select Batch</option>
                            <?php
                            if ($batches_result->num_rows > 0) {
                                while ($batch = $batches_result->fetch_assoc()) {
                                    $selected = ($batch['id'] == $current_batch_id) ? 'selected' : '';
                                    echo "<option value='{$batch['id']}' $selected>{$batch['course_name']}</option>";
                                }
                            } else {
                                echo "<option value='' disabled>No batches available</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <!-- Test Name -->
                    <div class="col-12 col-lg-3 mb-3">
                        <label for="test_name" class="form-label">Test Name</label>
                        <input type="text" class="form-control" placeholder="Enter Test Name" name="test_name"
                            value="<?php echo htmlspecialchars($row['test_name']); ?>" required>
                    </div>

                    <!-- Start Date -->
                    <div class="col-6 col-lg-3 mb-3">
                        <label for="strt_date" class="form-label">Start Date</label>
                        <input type="date" class="form-control" name="strt_date"
                            value="<?php echo htmlspecialchars($row['strt_date']); ?>" required>
                    </div>

                    <!-- End Date -->
                    <!-- <div class="col-6 col-lg-3 mb-3">
                        <label for="end_date" class="form-label">End Date</label>
                        <input type="date" class="form-control" name="end_date"
                            value="<?php echo htmlspecialchars($row['end_date']); ?>" required>
                    </div> -->

                    <!-- Result Date -->
                    <!-- <div class="col-6 col-lg-3 mb-3">
                        <label for="rslt_date" class="form-label">Result Date</label>
                        <input type="date" class="form-control" name="rslt_date"
                            value="<?php echo htmlspecialchars($row['rslt_date']); ?>" required>
                    </div> -->

                    <!-- Positive Mark -->
                    <!-- <div class="col-6 col-lg-3 mb-3">
                        <label for="pt_mrk" class="form-label">Positive Mark</label>
                        <input type="number" step="0.01" class="form-control" name="pt_mrk"
                            placeholder="Enter Positive Mark" value="<?php echo htmlspecialchars($row['pt_mark']); ?>"
                            required>
                    </div> -->

                    <!-- Negative Mark -->
                    <!-- <div class="col-6 col-lg-3 mb-3">
                        <label for="ng_mrk" class="form-label">Negative Mark</label>
                        <input type="number" step="0.01" class="form-control" name="ng_mrk"
                            placeholder="Enter Negative Marks" value="<?php echo htmlspecialchars($row['ng_mark']); ?>"
                            required>
                    </div> -->

                    <div class="col-6 col-lg-3 mb-3">
                        <label for="t_time" class="form-label">Total Time</label>
                        <input type="number" class="form-control" name="t_time"
                            value="<?php echo htmlspecialchars($row['t_time']); ?>" required>
                    </div>

                    <!-- Status Dropdown -->
                    <div class="col-6 col-lg-3 mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select class="form-select" name="status" required>
                            <option value="active" <?php echo ($current_status === 'active') ? 'selected' : ''; ?>>
                                Active</option>
                            <option value="inactive" <?php echo ($current_status === 'inactive') ? 'selected' : ''; ?>>
                                Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="text-end">
                    <input type="submit" name="update_test" value="Update Test" class="btn btn-primary">
                    <a href="view-test.php" class="btn btn-secondary">Back</a>
                </div>
            </form>
        </div>
    </div>
</div>


<?php include 'footer.php'; ?>