<?php
session_start();

include "../connection.php";
if (!isset($_SESSION['mobile'])) {
    header("Location: login.php");
    exit();
}
$admin_id = $_SESSION['admin_id'];
$adminName = $_SESSION['admin_name'];
$sql = "SELECT role FROM org_details WHERE id = '$admin_id'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $role = $row['role'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="icon" type="image/x-icon" href="../assets/images/utkarsh_fevicon.png">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8"
        src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
   <link rel="stylesheet" href="./src/styles/style.css">
</head>

<body>

    <div class="sidebar" id="sidebar">
        <h2 class="text-center mt-3">Admin Panel</h2>
        <nav class="nav flex-column">
            <li class="nav-item dropdown">
                <a class="nav-link active no-drop" href="index.php">
                <i class="fa fa-home fs-5 text-light ms-2 me-2"></i>
                    <span class="mtext">Dashboard</span>
                </a>
            </li>

            <?php if ($role == "admin") { ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#manage-course-submenu">
                    <i class="fa  fa-book-open fs-5 text-light ms-2 me-2"></i>
                        <span class="mtext">Manage Course</span>
                    </a>
                    <ul id="manage-course-submenu" class="collapse menusub">
                        <li class="nav-item">
                            <a href="add-course.php" class="d-flex align-items-center nav-link">
                                <i class="fa fa-user fs-5 text-light ms-2 me-2"></i> Add Course
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="view-course.php" class="d-flex align-items-center nav-link">
                                <i class="fa fa-eye text-light fs-5 ms-2 me-2"></i> View Course
                            </a>
                        </li>
                    </ul>
                </li>
            <?php } ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#manage-student-submenu">
                <i class="fa  fa-user-graduate fs-5 text-light ms-2 me-2"></i>
                    <span class="mtext">Manage Student</span>
                </a>
                <ul id="manage-student-submenu" class="collapse menusub">
                    <li class="nav-item">
                        <a href="add-student.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-user fs-5 text-light ms-2 me-2"></i> Add Student
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="view-student.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-eye text-light fs-5 ms-2 me-2"></i> View Student
                        </a>
                    </li>
                </ul>
            </li>
            
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#manage-test-submenu">
                    <i class="fa fa-book-reader text-light fs-5 ms-2 me-2"></i> 
                    <span class="mtext">Create Exam</span>
                </a>
                <ul id="manage-test-submenu" class="collapse menusub">
                    <li class="nav-item">
                        <a href="add-test.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-book fs-5 text-light ms-2 me-2"></i> Add Exam
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="view-test.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-eye fs-5 text-light ms-2 me-2"></i> View Exam
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#manage-exam-submenu">
                    <i class="fa fa-book-reader text-light fs-5 ms-2 me-2"></i> 
                    <span class="mtext">Assign Exam</span>
                </a>
                <ul id="manage-exam-submenu" class="collapse menusub">
                    <li class="nav-item">
                        <a href="create-exam.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-book fs-5 text-light ms-2 me-2"></i>Assign Exam
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="view-exam-list.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-eye fs-5 text-light ms-2 me-2"></i> View Exam Assign list
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item dropdown d-block d-lg-none">
                <a class="nav-link dropdown-toggle" data-bs-toggle="collapse" data-bs-target="#manage-profile-submenu">
                <i class="fa fa-user text-light fs-5 ms-2 me-2"></i> 
                    <span class="mtext">Manage Profile</span>
                </a>
                <ul id="manage-profile-submenu" class="collapse menusub">
                    <li class="nav-item">
                        <a href="profile.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-edit fs-5 text-light ms-2 me-2"></i> Update Profile
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="logout.php" class="d-flex align-items-center nav-link">
                            <i class="fa fa-sign-out-alt fs-5 text-light ms-2 me-2"></i> Logout
                        </a>
                    </li>
                </ul>
            </li>
        </nav>

    </div>

    <div class="main">
        <div class="header d-flex justify-content-between align-items-center">
            <div>
                <span class="me-2">Welcome,<strong class="text-uppercase"> <?php echo htmlspecialchars($adminName); ?></strong></span>
            </div>
            <button class="btn btn-primary d-block d-lg-none" id="toggleSidebar"><i class="fas fa-bars"></i></button>
            <div class="dropdown d-none d-lg-block">
                <a class="" href="#" role="button" data-bs-toggle="dropdown">
                    <span class="btn btn-danger"> Menu</span>
                </a>
                <ul class="dropdown-menu ">
                    <li><a class="dropdown-item" href="profile.php"><i class="dw dw-user1"></i> Profile</a></li>
                    <li><a class="dropdown-item" href="logout.php"><i class="dw dw-logout"></i> Log Out</a></li>
                </ul>
            </div>
        </div>