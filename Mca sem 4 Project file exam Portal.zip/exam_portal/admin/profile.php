<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'header.php';
if (isset($_SESSION['admin_id'])) {
	$admin_id = $_SESSION['admin_id'];
	// echo ("admin_id: ". $admin_id);
	$stmt = $conn->prepare("SELECT * FROM org_details WHERE id = ?");
	$stmt->bind_param("i", $admin_id);
	$stmt->execute();
	$result = $stmt->get_result();
	$adminData = $result->fetch_assoc();

	if (isset($_POST['updateProfile'])) {
		$admin_name = $_POST['admin_name'];
		$admin_mobile = $_POST['admin_mobile'];
		$org_name = $_POST['org_name'];
		$admin_location = $_POST['admin_location'];


		$stmt = $conn->prepare("UPDATE org_details SET owner_name = ?, mobile = ?,  org_name = ?, location = ? WHERE id = ?");
		$stmt->bind_param("ssssi", $admin_name, $admin_mobile, $org_name,  $admin_location, $admin_id);

		if ($stmt->execute()) {
			echo "
			<script>
			 alert('Profile updated Successfully');
			 </script>
			 ";
			$stmt = $conn->prepare("SELECT * FROM org_details WHERE id = ?");
			$stmt->bind_param("i", $admin_id);
			$stmt->execute();
			$result = $stmt->get_result();
			$adminData = $result->fetch_assoc();
		} else {
			echo "<script>
			 alert('Profile Not Updated.');
			 </script>";
		}
	}
} else {
	echo "<div class='alert alert-danger'>Admin not logged in. Please log in first.</div>";
	exit();
}
?>


	<div class="content">
		<div class="container mt-4">
			<div class="profile shadow p-3 bg-light rounded">
				<h5 class="text-center">Update Your Profile</h5>
				<hr>
				<div class="profile-form mt-3">
					<form method="POST" action="" enctype="multipart/form-data">
						<div class="row">
							<div class="col-12 col-lg-6 mb-3">
								<label for="admin_name" class="form-label">Name</label>
								<input type="text" class="form-control" placeholder="Enter Your Name" name="admin_name"
									value="<?php echo htmlspecialchars($adminData['owner_name']); ?>" required>
							</div>
							<div class="col-12 col-lg-6 mb-3">
								<label for="admin_mobile" class="form-label">Mobile</label>
								<input type="text" class="form-control" name="admin_mobile"
									value="<?php echo htmlspecialchars($adminData['mobile']); ?>" required>
							</div>
							
							<div class="col-12 col-lg-6 mb-3">
								<label for="org_name" class="form-label">Organization Name</label>
								<input type="text" class="form-control" name="org_name"
									value="<?php echo htmlspecialchars($adminData['org_name']); ?>" required>
							</div>
							<div class="col-12 col-lg-6 mb-3">
								<label for="admin_location" class="form-label">Location</label>
								<input type="text" class="form-control" name="admin_location"
									value="<?php echo htmlspecialchars($adminData['location']); ?>" required>
							</div>
						</div>
						<div class="text-end">
							<input type="submit" name="updateProfile" value="Update Profile" class="btn btn-success">
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<?php include "footer.php"; ?>