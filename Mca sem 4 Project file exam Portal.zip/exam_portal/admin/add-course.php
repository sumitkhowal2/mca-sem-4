<?php
include 'header.php';

if (isset($_POST['addCourse'])) {
    $course_name = $_POST['course_name'];

    $stmt = $conn->prepare("INSERT INTO course_details (course_name,admin_id, status, created_at) VALUES (?, ?, 'active', NOW())");
    $stmt->bind_param("si", $course_name, $admin_id);

    if ($stmt->execute()) {
        $_SESSION['status'] = "Course added successfully!";
        $_SESSION['status_code'] = "success";
        header("Location: add-course.php");
        
    } else {
        $_SESSION['status'] = "Failed to add course!";
        $_SESSION['status_code'] = "error";
        header("Location: add-course.php");
        
    }
}

if (isset($_POST['importfile'])) {
    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
        $file = $_FILES['file']['tmp_name'];
        $handle = fopen($file, 'r');

        fgetcsv($handle);  

        $stmt = $conn->prepare("INSERT INTO course_details (course_name,admin_id, status, created_at) VALUES (?,?, 'active', NOW())");

        $importedCourses = 0;

        while (($data = fgetcsv($handle)) !== FALSE) {
            $course_name = mb_convert_encoding($data[0], 'UTF-8', 'auto');
            $stmt->bind_param("si", $course_name, $admin_id);
            if ($stmt->execute()) {
                $importedCourses++;
            }
        }

        fclose($handle);

        $_SESSION['status'] = "$importedCourses courses imported successfully!";
        $_SESSION['status_code'] = "success";
        header("Location: add-course.php");
       
    } else {
        $_SESSION['status'] = "Failed to upload file!";
        $_SESSION['status_code'] = "error";
        header("Location: add-course.php");
       
    }
}
?>

<div class="content">
            <div class="container mt-4">
            <div class="add-course shadow p-3 bg-light rounded">
                <h5 class="text-center">Add Course</h5>
                <hr>
                <div class="add-course-form mt-3">
                    <form action="" method="post">
                        <div class="row">
                            <div class="col-lg-6 mb-3">
                                <label for="course_name" class="form-label">Course Name</label>
                                <input type="text" class="form-control" name="course_name" placeholder="Enter Course Name" required>
                            </div>

                            <div class="col-lg-6 d-flex">
                                <div class="d-flex align-items-center">
                                    <input type="submit" value="Add Course" name="addCourse" class="btn btn-success">
                                </div>
                            </div>
                        </div>
                    </form>

                    <div class="table-responsive d-none">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Course ID</th>
                                    <th>Course Name</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $sql = "SELECT * FROM course_details";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . $row['course_id'] . "</td>";
                                        echo "<td>" . $row['course_name'] . "</td>";
                                        echo "<td>" . $row['status'] . "</td>";
                                        echo "<td>" . $row['created_at'] . "</td>";
                                        echo "</tr>";
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- Import File Section -->
            <div class="import-course mt-4 shadow rounded p-3 bg-light">
                <h5 class="text-center">Import Course</h5>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-lg-6 mb-3">
                            <label for="file" class="form-label">Import Course</label>
                            <div>
                                <input type="file" class="form-control mb-2" name="file" required>
                                <a href="./src/files/sample-course-file.csv" class="" download="sample-course-file.csv">Click here to Download Sample File</a>
                            </div>
                            <!-- <small class="text-danger">* Only .csv file is allowed</small><br> -->
                        </div>
                        
                            <div class="text-end">
                                <input type="submit" value="Import File" name="importfile" class="btn btn-primary">
                            </div>
                        
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php
    if (isset($_SESSION['status']) && $_SESSION['status'] != '') {
        ?>
        <script>
            Swal.fire({
                icon: '<?php echo $_SESSION['status_code']; ?>',
                title: '<?php echo $_SESSION['status']; ?>',
                text: '<?php echo $_SESSION['status_code'] == "success" ? "Operation completed successfully." : "Please try again."; ?>',
                button: "Okay",
                timer: 2000,
            });
        </script>
        <?php
        unset($_SESSION['status']);
    }
    ?>

    <?php include 'footer.php'; ?>
