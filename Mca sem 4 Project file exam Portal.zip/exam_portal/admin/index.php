<?php
include 'header.php';

if ($role == 'admin') {
    $student_sql = "SELECT * FROM student_details WHERE status = 'active'";
    $test_sql = "SELECT * FROM test_details WHERE status = 'active'";
    $course_sql = "SELECT * FROM course_details WHERE status = 'active'";
    $assign_exam = "SELECT * FROM exam_assign_details WHERE status = 'active'";
} else {
    $student_sql = "SELECT * FROM student_details WHERE admin_id = $admin_id AND status = 'active'";
    $test_sql = "SELECT * FROM test_details WHERE admin_id = $admin_id AND status = 'active'";
    $assign_exam = "SELECT * FROM exam_assign_details WHERE status = 'active'";
}
$total_students = mysqli_num_rows(mysqli_query($conn, $student_sql));
$total_tests = mysqli_num_rows(mysqli_query($conn, $test_sql));
$total_courses = mysqli_num_rows(mysqli_query($conn, $course_sql));
$total_assign_exam = mysqli_num_rows(mysqli_query($conn, $assign_exam));
?>


<div class="content">
    <div class="container mt-4">
        <h2 class="mb-4">Statistics</h2>
        <div class="row">
            <?php if ($role == 'admin') { ?>
                <div class="col-md-4 col-sm-6">
                    <a href="view-course.php" class="text-decoration-none">
                        <div class="card text-white bg-danger mb-3">
                            <div class="card-header">Active Courses</div>
                            <div class="card-body">
                                <h3 class="card-title fw-bold"><?php echo $total_courses; ?></h3>
                                <p class="card-text">Number of Courses</p>
                            </div>
                        </div>
                    </a>
                </div>
            <?php } ?>
            <div class="col-md-4 col-sm-6">
                <a href="view-student.php" class="text-decoration-none">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-header">Active Students</div>
                        <div class="card-body">
                            <h3 class="card-title fw-bold"><?php echo $total_students; ?></h3>
                            <p class="card-text">Number of registered student</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="view-test.php" class="text-decoration-none">
                    <div class="card text-white bg-success mb-3">
                        <div class="card-header">Active Test</div>
                        <div class="card-body">
                            <h3 class="card-title fw-bold"><?php echo $total_tests; ?></h3>
                            <p class="card-text">Number of Test Created</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 col-sm-6">
                <a href="view-exam-list.php" class="text-decoration-none">
                    <div class="card text-white bg-info mb-3">
                        <div class="card-header">Active Assign Exam</div>
                        <div class="card-body">
                            <h3 class="card-title fw-bold"><?php echo $total_assign_exam; ?></h3>
                            <p class="card-text">Number of Assign Exam</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>


<?php include "footer.php"; ?>